#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "include/funciones.c"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography
#include <time.h>

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <sys/stat.h>

#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265

#define long_diag 50


//#define escalado_calculo 0.25
#define escalado_draw 0.25
#define ancho_escalado 340
#define largo_escalado 314

using namespace cv;
using namespace std;




string rutaFile;
string nameFileResultados;


int main(int argc, char * argv[])
{ 

	features myfeatures;
	accessFileString miAccess;

	//
	Mat sceneImgColor;
	Mat sceneImg;


	if (argc<4)
		{printf("ERROR: fallo al introducir los argumentos");myfeatures.showUsage("features_evaluacion");}

	int numPhotosScene = miAccess.numPhotos(argv[2]);
	printf("\nNumero de fotos de escenarios: %d\n",numPhotosScene);


	string nameDescriptor,nameExtractor;


	for(int j = 0; j<9;j++)
	{	
		char indDetector[10];
		sprintf(indDetector,"%d",j);
		string strDetector(indDetector);

		for(int k = 0;k<5;k++)
		{
			if(j==5 && k ==1)
				{k=2;}
			char indExtractor[10];
			sprintf(indExtractor,"%d",k);
			string strExtractor(indExtractor);

										
		
			printf("-----------------------\n");
			printf("Metodo: %s %s\n",strDetector.c_str(),strExtractor.c_str());

			for(int i=0;i<numPhotosScene;i++)
			{	//string nameResultado=ruta_resultado;
				string nameResultado(argv[3]);
	
				string rutaScene =  miAccess.getRuta (argv[2],i);
				string name_scene = miAccess.readName(rutaScene);
				nameResultado.append("/");
				nameResultado.append(name_scene);
				nameResultado.append(".png");

				printf("\tImagen: %s\n",name_scene.c_str());
				sceneImgColor = myfeatures.image_input(rutaScene,"features_pruebas",0.75);
				sceneImg = sceneImgColor.clone();
				cvtColor(sceneImg, sceneImg, CV_BGR2GRAY); //convertimos a blanco y negro
	
	



				string rutaPhoto =  string(argv[1]);
				string name_object = miAccess.readName(rutaPhoto);	
				Mat objectImgColor = myfeatures.image_input(rutaPhoto,"features_pruebas",0.15);
				//imshow(name_object,objectImgColor);
				Mat objectImg = objectImgColor.clone();
				cvtColor(objectImg, objectImg, CV_BGR2GRAY); //convertimos a blanco y negro

	


				vector<cv::KeyPoint> objectKeypoints;
				vector<cv::KeyPoint> sceneKeypoints;
				Mat objectDescriptors;
				Mat sceneDescriptors;


				int repetido=0;

				int fin = 0;
	
				nameFileResultados="features_";
				rutaFile = argv[3];
				rutaFile.append("/");

				myfeatures.detect_extract_object(strDetector,strExtractor,objectKeypoints,objectDescriptors,objectImg,nameDescriptor,nameExtractor);



				nameFileResultados.append(nameDescriptor);nameFileResultados.append("_");
				nameFileResultados.append(nameExtractor);nameFileResultados.append(".txt");
				rutaFile.append(nameFileResultados);
	
				//cout<<"Ruta del archivo: "<<rutaFile<<endl;
				ofstream file;file.open(rutaFile.c_str(),fstream::app);
				file << rutaScene<<"\n";//primero escribimos el nombre de la imagen en el fichero
				file.close();

				while(!fin)
				{
	
				myfeatures.detect_extract_scene(strDetector,strExtractor,sceneKeypoints,sceneDescriptors,sceneImg);
		

					//////////////////////////////////////////////////////////////////////////
					// NEAREST NEIGHBOR MATCHING USING FLANN LIBRARY (included in OpenCV)  //
					/////////////////////////////////////////////////////////////////////////


					Mat results;
					Mat dists;
					int k=2;
					if (objectDescriptors.type()==CV_8U)
					{
						//Descriptores Binarios detectados (ORB o BRIEF)

						flann::Index flannIndex(sceneDescriptors, flann::LshIndexParams(12,20,2),cvflann::FLANN_DIST_HAMMING);

						flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());

					}
					else
					{
						//asumimos que es CV_32F
						//Creamos Flann KDTree index
						flann::Index flannIndex(sceneDescriptors, flann::KDTreeIndexParams(),cvflann::FLANN_DIST_EUCLIDEAN);

						flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
					}
					//conversion a CV_32F si es necesario
					if (dists.type() == CV_32S)
					{
						Mat temp;
						dists.convertTo(temp,CV_32F);
						dists = temp;	
					}	

					////////////////////////////////////////
					//Procesamiento de el resultado del vecino mas cercano
					////////////////////////////////////////
					//Encontramos la correspondencia por NNDR (Nearest Neighbor Distance Ratio)

					float nndrRatio = 0.8;
					vector<Point2f> obj,scene;
					vector<int> indexes_1, indexes_2;
					vector<uchar> inlier_mask;



					for(unsigned int i=0; i<objectDescriptors.rows;i++)
					{	
						//printf("q=%d dist1=%f dist2=%f\n", i, dists.at<float>(i,0), dists.at<float>(i,1));
						if (results.at<int>(i,0)>=0 && results.at<int>(i,1)>=0 && dists.at<float>(i,0)<=nndrRatio * dists.at<float>(i,1))
						{
						obj.push_back(objectKeypoints.at(i).pt);
						indexes_1.push_back(i);



						scene.push_back(sceneKeypoints.at(results.at<int>(i,0)).pt);
						indexes_2.push_back(results.at<int>(i,0));

						}

					}


				  	Mat img_matches(sceneImg.size(),CV_8UC3);
					cvtColor(sceneImg, img_matches, CV_GRAY2RGB);
					vector<KeyPoint> inliers1, inliers2;
					vector<DMatch> inlier_matches;
					vector<Point2f> scene_corners(4);
	
					vector<Point2f> obj_corners(4);
					//find homography
					int nbMatches = 8;


					






					if(obj.size() >= nbMatches)
					{
					Mat H = findHomography(	obj,scene,RANSAC,1,inlier_mask);

						int inliers=0, outliers=0;
						for(unsigned int k=0; k<obj.size();++k)
							{
								if(inlier_mask.at(k))
								{
									++inliers;
								   
								}
								else
								{
									++outliers;
								}
							}


					//printf("Inliers=%d Outliers=%d\n", inliers, outliers);
					perspectiveTransform( obj, scene, H);	


					obj_corners[0] = Point(0,0); obj_corners[1] = Point( objectImg.cols, 0 );
					obj_corners[2] = Point( objectImg.cols, objectImg.rows ); obj_corners[3] = Point( 0, objectImg.rows );


					perspectiveTransform( obj_corners, scene_corners, H);
	
					//imshow(name_object,objectImgColor);	

	
					if(myfeatures.calcula_detectado(scene_corners)==true)
					{	//printf("\t'%s' repetido\n",name_object.c_str());
						myfeatures.DrawBoundingBox(scene_corners,sceneImgColor,sceneImgColor,inliers,outliers,name_object);	
						myfeatures.borrar_seccion(scene_corners,sceneImg);
						repetido++;
						//guardamos en list_of_dt.txt
						vector<int> mislimites = myfeatures.limits(scene_corners);
						Point pt1,pt2;
						pt1.x = mislimites.at(0);pt1.y = mislimites.at(2);
						pt2.x = mislimites.at(1);pt2.y = mislimites.at(3);
			
						miAccess.writeinfile(rutaFile,rutaPhoto, pt1, pt2);
					}
					else
					{
						fin =  1;
						printf("\tVeces que '%s' se ha repetido en '%s.png': %d \n",name_object.c_str(),name_scene.c_str(),repetido);
					}




					}
					else
					{	fin = 1;
						printf("No hay suficientes coincidencias (%d) para homografia para %s\n", (int)obj.size(),name_object.c_str());
					}	
	
				}//while fin



			//imwrite(nameResultado,sceneImgColor);
			//name_scene.append(" resultante");
			//imshow(name_scene,sceneImgColor);
			}//for scene

		}//for Extractor
	}//for detector

	waitKey(0);
	return 1;

}


