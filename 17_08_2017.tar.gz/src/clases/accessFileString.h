#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctime>


#include <fstream>
#include <stdexcept>
#include <sys/stat.h>
#include <string> 
#include <iostream>    

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography



#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265
#define escalado_calculo 0.5
#define escalado_draw 0.25
#define long_diag 50
using namespace cv;
using namespace std;


class accessFileString
{

public:

	string readName(string rutaName);
	int numPhotos(string ruta); 
	string getRuta (string ruta, int indice);
	bool checkname(const string rutaFile,const string nameImage);
	void writeinfile(const string rutaFile,const string nameImage, Point pt1, Point pt2);	
	int numberofdeteccions(const string rutaFile, const string nameImage);
	void extractDeteccions(const string rutaFile, const string nameImage, Point &pt1, Point &pt2, int indice);

	

};
