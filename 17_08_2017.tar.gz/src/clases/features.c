
/////***********************************************************///////////
/////			features				///////////
/////***********************************************************///////////
#include "features.h"

void features::showUsage(const string node)
{	
	printf("\n");
	printf("USO:\n");

	if(node == "hog_ruta")
	{
	printf("rosrun hog ruta escenarios.txt list_of_gd.txt\n\n");
	}
	
	if (node == "features_video")
	{
	printf("rosrun features features_video argv[1] argv[2] argv[3] ...\n\n");
	
	}

	if (node == "features_image")
	{
	printf("rosrun features features_image argv[1] argv[2] argv[3] argv[4]...\n\n");

	}
	
	if (node == "features_pruebas")
	{
	printf("rosrun features features_ruta argv[1] argv[2] argv[3] argv[4] argv[5]\n\n");
	
	}

	if (node == "features_evaluacion")
	{
	printf("rosrun features features_evaluacion argv[1] argv[2] argv[3]\n\n");
	}
	
	if (node !="features_evaluacion"&& node != "hog_ruta")
	{
	printf("------------------------------------------------------\n\n");
	printf("argv[1] -> metodo del Detector: \n");
	printf("0->DenseFeatureDetector\n");
	printf("1->FastFeatureDetector\n");
	printf("2->GFTTDetector\n");
	printf("3->MSER\n");
	printf("4->ORB\n");	
	printf("5->SIFT\n");
	printf("6->StarFeatureDetector\n");
	printf("7->SURF\n");
	printf("8->BRISK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[2] -> metodo del Extractor: \n");
	printf("0->BriefDescriptorExtractor\n");
	printf("1->ORB\n");
	printf("2->SIFT\n");
	printf("3->SURF\n");
	printf("4->BRISK\n");
	printf("5->FREAK\n");
	printf("------------------------------------------------------\n\n");
	}
	if (node == "features_video")
	{

	printf("argv[3] -> Imagen del objeto\n");	
	}

	if (node == "features_image")
	{

	printf("argv[3] -> Imagen de la escena\n");	
	printf("argv[4] -> Imagen del objeto\n");
	}
	
	if (node == "features_pruebas")
	{

	printf("argv[3] -> ruta al fichero del objeto\n");	
	printf("argv[4] -> ruta al fichero del escenario\n");
	printf("argv[5] -> ruta a la carpeta de resultados\n");	
	}
	

	if (node == "features_evaluacion")
	{

	printf("argv[1] -> ruta a la imagen que usaremos como base\n");	
	printf("argv[2] -> ruta al fichero del escenario\n");
	printf("argv[3] -> ruta a la carpeta de resultados\n");	
	}
	
	exit(1);

}

void features::detect_extract_object(const string Descriptor, const string Extractor,vector<KeyPoint> &objectKeypoints,Mat &objectDescriptors, Mat objectImg,string &nameDescriptor,string &nameExtractor)
{

switch(atoi(Descriptor.c_str()))
	{
		case 0:	
				{
				FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
				detector_Dense->detect(objectImg, objectKeypoints);  delete detector_Dense;
				nameDescriptor = "DenseFeatureDetector";
				break;}
		
		case 1:	
				{
				FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
				detector_Fast->detect(objectImg, objectKeypoints);  delete detector_Fast;
				nameDescriptor = "DenseFastDetector";break;}


		case 2:	
				{
				FeatureDetector *detector_GFTT = new GFTTDetector();
				detector_GFTT->detect(objectImg, objectKeypoints);  delete detector_GFTT;
				nameDescriptor = "GFTTDetector";break;}
		case 3: 
				{
				FeatureDetector *detector_MSER = new MSER();
				detector_MSER->detect(objectImg, objectKeypoints);  delete detector_MSER;
				nameDescriptor = "MSER";break;}

		case 4:	
				{
				FeatureDetector *detector_ORB =  new ORB();
				detector_ORB->detect(objectImg, objectKeypoints);  delete detector_ORB;
				nameDescriptor = "ORB";break;}
		case 5:	
				{
				FeatureDetector *detector_SIFT = new SIFT();	
				detector_SIFT->detect(objectImg, objectKeypoints);  delete detector_SIFT;
				nameDescriptor = "SIFT";break;}
		case 6: 
				{
				FeatureDetector *detector_Star =  new StarFeatureDetector();
				detector_Star->detect(objectImg, objectKeypoints);  delete detector_Star;
				nameDescriptor = "StarFeatureDetector";break;}
	
		case 7:	
				{
				FeatureDetector *detector_SURF = new SURF(600.0);
				detector_SURF->detect(objectImg, objectKeypoints);  delete detector_SURF;
				nameDescriptor = "SURF";break;}

		case 8:	
				{
				FeatureDetector *detector_BRISK =  new BRISK();
				detector_BRISK->detect(objectImg, objectKeypoints);  delete detector_BRISK;
				nameDescriptor = "BRISK";break;}

	}	

	switch(atoi(Extractor.c_str()))
	{	
		case 0: 
				{
				DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
				extractor_BRIEF->compute(objectImg,objectKeypoints, objectDescriptors);	delete extractor_BRIEF;
				nameExtractor = "BriefDescriptor";break;}
		case 1:	
				{
				DescriptorExtractor *extractor_ORB = new ORB();
				extractor_ORB->compute(objectImg,objectKeypoints, objectDescriptors); delete extractor_ORB;
				nameExtractor = "ORB";break;}
		case 2:	
				{
				DescriptorExtractor *extractor_SIFT = new SIFT();
				extractor_SIFT->compute(objectImg,objectKeypoints, objectDescriptors); delete extractor_SIFT;
				nameExtractor = "SIFT";break;}
		case 3:	
				{
				DescriptorExtractor *extractor_SURF = new SURF(600.0);
				extractor_SURF->compute(objectImg,objectKeypoints, objectDescriptors); delete extractor_SURF;
				nameExtractor = "SURF";break;}
		case 4:	
				{
				DescriptorExtractor *extractor_BRISK = new BRISK();
				extractor_BRISK->compute(objectImg,objectKeypoints, objectDescriptors); delete extractor_BRISK;
				nameExtractor = "BRISK";break;}	
		case 5:	
				{
				DescriptorExtractor *extractor_FREAK = new FREAK();
				extractor_FREAK->compute(objectImg,objectKeypoints, objectDescriptors); delete extractor_FREAK;
				nameExtractor = "FREAK";break;}
	}





}


void features::detect_extract_scene(const string Descriptor, const string Extractor,vector<KeyPoint> &sceneKeypoints,Mat &sceneDescriptors, Mat sceneImg)
{

switch(atoi(Descriptor.c_str()))
	{
		case 0:	
				{
				FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
				detector_Dense->detect(sceneImg, sceneKeypoints);delete detector_Dense;	break;}
		
		case 1:	
				{
				FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
				detector_Fast->detect(sceneImg, sceneKeypoints);delete detector_Fast;break;}


		case 2:	
				{
				FeatureDetector *detector_GFTT = new GFTTDetector();
				detector_GFTT->detect(sceneImg, sceneKeypoints);delete detector_GFTT;break;}
		case 3: 
				{
				FeatureDetector *detector_MSER = new MSER();
				detector_MSER->detect(sceneImg, sceneKeypoints);delete detector_MSER;break;}

		case 4:	
				{
				FeatureDetector *detector_ORB =  new ORB();
				detector_ORB->detect(sceneImg, sceneKeypoints);	delete detector_ORB;break;}
		case 5:	
				{
				FeatureDetector *detector_SIFT = new SIFT();	
				detector_SIFT->detect(sceneImg, sceneKeypoints);delete detector_SIFT;break;}
		case 6: 
				{
				FeatureDetector *detector_Star =  new StarFeatureDetector();
				detector_Star->detect(sceneImg, sceneKeypoints);delete detector_Star;break;}
	
		case 7:	
				{
				FeatureDetector *detector_SURF = new SURF(600.0);
				 detector_SURF->detect(sceneImg, sceneKeypoints);delete detector_SURF;break;}

		case 8:	
				{
				FeatureDetector *detector_BRISK =  new BRISK();
				detector_BRISK->detect(sceneImg, sceneKeypoints);delete detector_BRISK;break;}

	}	

	switch(atoi(Extractor.c_str()))
	{	
		case 0: 
				{
				DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
				extractor_BRIEF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRIEF;break;}
		case 1:	
				{
				DescriptorExtractor *extractor_ORB = new ORB();
				extractor_ORB->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_ORB;break;}
		case 2:	
				{
				DescriptorExtractor *extractor_SIFT = new SIFT();
				extractor_SIFT->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SIFT;break;}
		case 3:	
				{
				DescriptorExtractor *extractor_SURF = new SURF(600.0);
				extractor_SURF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SURF;break;}
		case 4:	
				{
				DescriptorExtractor *extractor_BRISK = new BRISK();
				extractor_BRISK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRISK;break;}		
		case 5:	
				{
				DescriptorExtractor *extractor_FREAK = new FREAK();
				extractor_FREAK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_FREAK;break;}
	}



}



void features::borrar_seccion(vector<Point2f> corners, Mat &sceneImg)
{
	vector<int> mylimits = limits(corners);

	for (int i = 0; i < sceneImg.rows; i++)
	{
    	for (int j = 0; j < sceneImg.cols; j++)
		{
		  if(j>mylimits.at(0) && j<mylimits.at(1)
			&& i>mylimits.at(2) && i<mylimits.at(3))
			{	//printf("borrando\n");
					sceneImg.at<uchar>(i, j) = 0;
			}

			

		}
	}

}

vector<int> features::limits(vector<Point2f> ptos)
{	vector<int> myvector;
	int min_x=ptos[0].x;int min_y=ptos[0].y;
	int max_x=0;int max_y=0;
	for (int i=0;i<4;i++)
	{		
		if (ptos[i].x<min_x && ptos[i].x>0.1)
		{min_x=ptos[i].x;}
		if (ptos[i].y<min_y && ptos[i].y>0.1)
		{min_y=ptos[i].y;}

		if (ptos[i].x>max_x)
		{max_x=ptos[i].x;}
		if (ptos[i].y>max_y)
		{max_y=ptos[i].y;}
		
	}
	myvector.push_back(min_x);
	myvector.push_back(max_x);		
	myvector.push_back(min_y);	
	myvector.push_back(max_y);	


	return myvector;
}

bool features::calcula_detectado(vector<Point2f> corners){
	//calculo del angulo

	float diag1,diag2,dif;	
	diag1=sqrt((corners[3].x-corners[0].x)*(corners[3].x-corners[0].x)+
   (corners[3].y-corners[0].y)*(corners[3].y-corners[0].y));
	diag2=sqrt((corners[2].x-corners[1].x)*(corners[2].x-corners[1].x)+
	(corners[2].y-corners[1].y)*(corners[2].y-corners[1].y));
	//printf("diag1: %f\tdiag2: %f\n",diag1,diag2);
	dif=abs(diag1-diag2);	
	bool result = false;
	
	if (dif<40 && diag1>long_diag)
	{
		
		result=true;
	}
	
	return result;


}

void features::DrawBoundingBox(vector<Point2f> corners,Mat src,Mat &dst,int inliers, int outliers, string name)
{

	dst = src.clone();
	char str[50];
	
	line(dst, corners[0] , corners[1] , Scalar(0, 255, 0), 2 );
	line(dst, corners[1] , corners[2] , Scalar( 0, 255, 0), 2 );
	line(dst, corners[2] , corners[3] , Scalar( 0, 255, 0), 2 );
	line(dst, corners[3] , corners[0] , Scalar( 0, 255, 0), 2 );
	
	//calculo del angulo
	float incx,incy,ang;
	  
	incx = corners[0].x-corners[1].x;
	incy = corners[0].y-corners[1].y;	
	ang = atan(incy/incx) * 180/PI*-1;
	Point2f offset( (float)10, 10);
	sprintf(str,"%s ang:%f",name.c_str(),ang);
	putText(dst,str,corners[1]+offset,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));

	//Inliers y outliers	
	Point2f offset_in( (float)10, 25);
	sprintf(str,"Inliers: %d",inliers);
	putText(dst,str,corners[1]+offset_in,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));
	
	Point2f offset_out( (float)10, 40);
	sprintf(str,"Ouliers: %d",outliers);
	putText(dst,str,corners[1]+offset_out,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));	


}

void features::drawMultipleObject(int num,char** argv)
{	
	double dstWidth = 0;
	double dstHeight=0;
	Mat dst;
	Mat myImage;
	for (int i=0;i<num;i++)
	{
	myImage=imread(argv[3+i],CV_LOAD_IMAGE_COLOR);

	if(dstHeight<(myImage.rows*escalado_draw))
		dstHeight=myImage.rows*escalado_draw;
	dstWidth = dstWidth + (myImage.cols*escalado_draw);
	}
	dst = Mat(dstHeight, dstWidth, CV_8UC3, cv::Scalar(0,0,0));

	double inicioCols=0;
	for (int i=0;i<num;i++)
	{
	Mat myImage=imread(argv[3+i],CV_LOAD_IMAGE_COLOR);
	resize(myImage, myImage, Size(myImage.cols*escalado_draw,myImage.rows*escalado_draw), 0, 0, CV_INTER_LINEAR);
	myImage.copyTo(dst.rowRange(0, myImage.rows).colRange(inicioCols, inicioCols+myImage.cols));
	inicioCols = myImage.cols+inicioCols;
	}
	
	imshow("Objetos",dst);
	
}


Mat features::image_input(const string rutaPhoto, const string node,float escalado)
{
	



		Mat myImage = imread(rutaPhoto,CV_LOAD_IMAGE_COLOR);
		//cout<<"escalado: "<<escalado<<endl;
		
		if(myImage.empty())
		{
			printf("\nERROR al cargar la imagen:%sd\n",rutaPhoto.c_str());
			showUsage(node);
		}

		if (myImage.rows>640 && myImage.cols>480 && myImage.rows<2000 )
		{
		    //cout << "Dimensiones originaless "<<myImage.cols<<"x"<<myImage.rows<<endl;
			resize(myImage, myImage, Size(myImage.cols*escalado,myImage.rows*escalado), 0, 0, CV_INTER_LINEAR);
		    //cout << "Se ha redimensionado a "<<myImage.cols<<"x"<<myImage.rows<<endl;
		}
		
		if (myImage.rows>2000 && myImage.cols>2000 )
		{	escalado = 0.01;
		    //cout << "Dimensiones originaless "<<myImage.cols<<"x"<<myImage.rows<<endl;
			resize(myImage, myImage, Size(myImage.cols*escalado,myImage.rows*escalado), 0, 0, CV_INTER_LINEAR);
		    //cout << "Se ha redimensionado a "<<myImage.cols<<"x"<<myImage.rows<<endl;

		}
		
			
		
	return myImage;

}


