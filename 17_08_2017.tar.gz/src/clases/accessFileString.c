/////**********************************************************///////////////
/////			accessFileString			//////////////
/////**********************************************************//////////////

#include "accessFileString.h"

string accessFileString::readName(string rutaName)
{

std::size_t found = rutaName.find_last_of("/\\");
string name = rutaName.substr(found+1);
name.erase(name.length()-4,4);//borra .png
return name;


}


string accessFileString::getRuta (string ruta, int indice)
{	

	ifstream file(ruta.c_str());
	if(!file)
	{
		cout << "Error no se puede abrir el archivo: " << ruta << endl;
                exit(0);
	}
	int cont = 0;
	bool fin = false;
	string linea;
 	while( fin == false) 
	{ 
          if(cont == indice) 
             fin = true;
	  getline(file, linea);
	 cont++;
                

	}
	file.close();

	return linea;


}

int accessFileString::numPhotos( string ruta)
{
	

	ifstream file(ruta.c_str());
	if(!file)
	{
		cout << "Error no se puede abrir el archivo: " << ruta<< endl;
                exit(0);
	}
	int cont = 0;
	bool fin = false;
	string linea;
 	while(getline(file, linea)) 
	{
          
	  cont++;
                

	}
	file.close();
	

	return cont;
	

}

bool accessFileString::checkname(const string rutaFile,const string nameImage)
{
ifstream file(rutaFile.c_str());
bool result = false;

string linea;
 	while(getline(file, linea)) 
	{
          if (linea == nameImage)
			result = true;
                

	}
file.close();
return result;
}



void accessFileString::writeinfile(const string rutaFile,const string nameImage, Point pt1, Point pt2)
{	
	int num = numberofdeteccions(rutaFile,nameImage);
	fstream file;
	file.open(rutaFile.c_str());
	
	if(!file)
	{
		cout << "Error no se puede abrir el archivo: " << rutaFile.c_str() << endl;
        exit(0);
	}

	
	
	int fin = 0,inicio = 0,cont = 0;
	string linea;

	while(!fin&&!file.eof()) 
		{	
		  getline(file, linea);
		  
          
         
		  if (linea == nameImage)
			{inicio=1;}

		 if (inicio == 1)	//comienzo a contar 
		{
			if (cont == num)//escribimos los datos 
			{				
				char str[100];
				sprintf(str,"\t%d %d %d %d\n",pt1.x,pt1.y,pt2.x,pt2.y);
				
				
				string dat(str);
				file << dat;
				file.close();
				fin = 1;
			}
			else
			{
				cont++;			
			}
		}
		}

	

}


int accessFileString::numberofdeteccions(const string rutaFile, const string nameImage)
{	
		int cont =0;
	
		ifstream file(rutaFile.c_str());
		if(!file)
		{
		cout << "Error no se puede abrir el archivo: " << rutaFile.c_str() << endl;
        exit(0);
		}


		int fin = 0;
		int inicio = 0;
		string tab,linea;
		
 		while(!fin&&!file.eof()) 
		{	
		  getline(file, linea);
		  //printf("lin: %s\n",linea.c_str());
          
          if (inicio == 1)	//comienzo a contar 
			{
				tab = linea.substr(0,1);
				if(tab=="\t") 
					{
						cont++;
					}			
				else
				{fin = 1;}
			}
		  if (linea == nameImage)
			{inicio=1;}
		}
		
		if (cont==0)
			{cout<<"No tiene ninguna deteccion escrita"<<endl;}
		
	file.close();

return cont;
}

void accessFileString::extractDeteccions(const string rutaFile, const string nameImage, Point &pt1, Point &pt2, int indice)
{
		int cont =0;
	
		ifstream file(rutaFile.c_str());
		if(!file)
		{
		cout << "Error no se puede abrir el archivo: " << rutaFile.c_str() << endl;
        exit(0);
		}



		int fin = 0;
		int inicio = 0;
		string tab,linea;
		
 		while(!fin) 
		{	
		  getline(file, linea);
		  //printf("lin: %s\n",linea.c_str());
          
          if (inicio == 1)	//comienzo a contar 
			{
				tab = linea.substr(0,1);
				if(tab=="\t")//inicio de la linea de datos 
					{
					if(cont == indice)
					{
						linea.erase(0,1);//eliminamos el '\t'
						stringstream ss(linea);
						ss >> pt1.x >> pt1.y >> pt2.x >> pt2.y;
						fin = 1;	
					}
					else
					{
						cont++;				
					}
					}			
				else
				{
					fin = 1;
				}

			}
		  if (linea == nameImage)
			{inicio=1;}
		}
		
		
		
	file.close();




}


