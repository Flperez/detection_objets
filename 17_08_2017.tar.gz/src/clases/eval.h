#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctime>


#include <fstream>
#include <stdexcept>
#include <sys/stat.h>
#include <string> 
#include <iostream>    

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography

using namespace cv;
using namespace std;

class eval
{

public:
	int area_union(vector<int> detectado,vector<int> teorico);
	int area_interseccion(vector<int> detectado, vector<int> teorico,Mat &img);
	vector<Point2f> extraccion_datos(const string rutaFile, int indice);
	bool solapamiento(int area_interseccion, int area_union,float umbral);
	
	

};

