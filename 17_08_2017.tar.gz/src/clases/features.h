#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctime>


#include <fstream>
#include <stdexcept>
#include <sys/stat.h>
#include <string> 
#include <iostream>    

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography



#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265
#define escalado_calculo 0.5
#define escalado_draw 0.25
#define long_diag 50
using namespace cv;
using namespace std;

static const std::string OPENCV_WINDOW = "Scene with Bounding Box";



class features
{

public:
	void showUsage(const string node);
	void drawMultipleObject(int num,char** argv);
	bool calcula_detectado(vector<Point2f> corners);
	void borrar_seccion(vector<Point2f> corners, Mat &sceneImg);
	vector<int> limits(vector<Point2f> ptos);
	void DrawBoundingBox(vector<Point2f> corners,Mat src,Mat &dst,int inliers, int outliers, string name);
	int numPhotos(string ruta); 
	void detect_extract_object(const string Descriptor, const string Extractor,vector<KeyPoint> &objectKeypoints,Mat &objectDescriptors, Mat objectImg,string &nameDescriptor,string &nameExtractor);
	void detect_extract_scene(const string Descriptor, const string Extractor,vector<KeyPoint> &sceneKeypoints,Mat &sceneDescriptors, Mat sceneImg);
	Mat image_input(const string rutaPhoto, const string node,float escalado);


};

