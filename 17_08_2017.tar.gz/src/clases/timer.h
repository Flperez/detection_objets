#include <ctime>


class Timer
{
public:
    Timer(); 
    double elapsed(); 
    void reset();

private:
    timespec beg_, end_;
};
