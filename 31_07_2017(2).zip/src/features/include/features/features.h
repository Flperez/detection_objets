#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#include <fstream>
#include <stdexcept>
#include <sys/stat.h>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography



#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265
#define escalado_calculo 0.5
#define escalado_draw 0.25
#define long_diag 50
using namespace cv;
using namespace std;

static const std::string OPENCV_WINDOW = "Scene with Bounding Box";



class features
{



public:

	string readName(char** argv,int indice);	
	Mat image_input(char** argv,int indice);
	void calcula_descriptor_extractor(char **argv);
	bool calcula_detectado(vector<Point2f> corners);
	void borrar_seccion(vector<Point2f> corners);
	vector<int> limits(vector<Point2f> ptos);
	void DrawBoundingBox(vector<Point2f> corners,Mat img,int inliers, int outliers,string name);
};


void showUsage();
void drawMultipleObject(int num,char** argv);


