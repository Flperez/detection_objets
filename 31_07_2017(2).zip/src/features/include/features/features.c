# include "features.h"
void showUsage()
{
	printf("\n");
	printf("USO:\n");
	printf("rosrun features features_video argv[1] argv[2] argv[3] ...\n\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[1] -> metodo del Detector: \n");
	printf("0->DenseFeatureDetector\n");
	printf("1->FastFeatureDetector\n");
	printf("2->GFTTDetector\n");
	printf("3->MSER\n");
	printf("4->ORB\n");	
	printf("5->SIFT\n");
	printf("6->StarFeatureDetector\n");
	printf("7->SURF\n");
	printf("8->BRISK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[2] -> metodo del Extractor: \n");
	printf("0->BriefDescriptorExtractor\n");
	printf("1->ORB\n");
	printf("2->SIFT\n");
	printf("3->SURF\n");
	printf("4->BRISK\n");
	printf("5->FREAK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[3] -> Imagen del objeto\n");	
	exit(1);
}


void ImageConverter::calcula_descriptor_extractor(char **argv)
{
	switch(atoi(argv[1]))
	{
		case 0:	
				{
				FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
				detector_Dense->detect(objectImg, objectKeypoints);  detector_Dense->detect(sceneImg, sceneKeypoints);
				delete detector_Dense;
				break;}
		
		case 1:	
				{
				FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
				detector_Fast->detect(objectImg, objectKeypoints);  detector_Fast->detect(sceneImg, sceneKeypoints);
				delete detector_Fast;break;}


		case 2:	
				{
				FeatureDetector *detector_GFTT = new GFTTDetector();
				detector_GFTT->detect(objectImg, objectKeypoints);  detector_GFTT->detect(sceneImg, sceneKeypoints);
				delete detector_GFTT;break;}
		case 3: 
				{
				FeatureDetector *detector_MSER = new MSER();
				detector_MSER->detect(objectImg, objectKeypoints);  detector_MSER->detect(sceneImg, sceneKeypoints);
				delete detector_MSER;break;}

		case 4:	
				{
				FeatureDetector *detector_ORB =  new ORB();
				detector_ORB->detect(objectImg, objectKeypoints);  detector_ORB->detect(sceneImg, sceneKeypoints);
				delete detector_ORB;break;}
		case 5:	
				{
				FeatureDetector *detector_SIFT = new SIFT();	
				detector_SIFT->detect(objectImg, objectKeypoints);  detector_SIFT->detect(sceneImg, sceneKeypoints);
				delete detector_SIFT;
				break;}
		case 6: 
				{
				FeatureDetector *detector_Star =  new StarFeatureDetector();
				detector_Star->detect(objectImg, objectKeypoints);  detector_Star->detect(sceneImg, sceneKeypoints);
				delete detector_Star;break;}
	
		case 7:	
				{
				FeatureDetector *detector_SURF = new SURF(600.0);
				detector_SURF->detect(objectImg, objectKeypoints);  detector_SURF->detect(sceneImg, sceneKeypoints);
				delete detector_SURF;break;}

		case 8:	
				{
				FeatureDetector *detector_BRISK =  new BRISK();
				detector_BRISK->detect(objectImg, objectKeypoints);  detector_BRISK->detect(sceneImg, sceneKeypoints);
				delete detector_BRISK;break;}

	}	

	switch(atoi(argv[2]))
	{	
		case 0: 
				{
				DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
				extractor_BRIEF->compute(objectImg,objectKeypoints, objectDescriptors);	extractor_BRIEF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRIEF;break;}
		case 1:	
				{
				DescriptorExtractor *extractor_ORB = new ORB();
				extractor_ORB->compute(objectImg,objectKeypoints, objectDescriptors); extractor_ORB->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_ORB;break;}
		case 2:	
				{
				DescriptorExtractor *extractor_SIFT = new SIFT();
				extractor_SIFT->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SIFT->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SIFT;break;}
		case 3:	
				{
				DescriptorExtractor *extractor_SURF = new SURF(600.0);
				extractor_SURF->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SURF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SURF;break;}
		case 4:	
				{
				DescriptorExtractor *extractor_BRISK = new BRISK();
				extractor_BRISK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_BRISK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRISK;break;}		
		case 5:	
				{
				DescriptorExtractor *extractor_FREAK = new FREAK();
				extractor_FREAK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_FREAK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_FREAK;break;}
	}


}

Mat features::image_input(char** argv,int indice)
{
	Mat myImage = imread(argv[3+indice],CV_LOAD_IMAGE_COLOR);

		
		if(myImage.empty())
		{
			printf("\nERROR al cargar la imagen\n");
			showUsage();
		}

		if (myImage.rows>640 && myImage.cols>480)
		{
		//	printf("Las dimensiones de la imagen del objeto son: %dx%d.\n",myImage.cols,myImage.rows);
			resize(myImage, myImage, Size(myImage.cols*escalado_calculo,myImage.rows*escalado_calculo), 0, 0, CV_INTER_LINEAR);
		//	printf("Se ha dimensionado a un 50/100 .\n");
		}
	
	return myImage;

}

void features::borrar_seccion(vector<Point2f> corners)
{
	vector<int> mylimits = limits(corners);

	for (int i = 0; i < sceneImg.rows; i++)
	{
    	for (int j = 0; j < sceneImg.cols; j++)
		{
		  if(j>mylimits.at(0) && j<mylimits.at(1)
			&& i>mylimits.at(2) && i<mylimits.at(3))
			{	//printf("borrando\n");
					sceneImg.at<uchar>(i, j) = 0;
			}

			

		}
	}

}

vector<int> features::limits(vector<Point2f> ptos)
{	vector<int> myvector;
	int min_x=ptos[0].x;int min_y=ptos[0].y;
	int max_x=0;int max_y=0;
	for (int i=0;i<4;i++)
	{		
		if (ptos[i].x<min_x)
		{min_x=ptos[i].x;}
		if (ptos[i].y<min_y)
		{min_y=ptos[i].y;}

		if (ptos[i].x>max_x)
		{max_x=ptos[i].x;}
		if (ptos[i].y>max_y)
		{max_y=ptos[i].y;}
		
	}
	myvector.push_back(min_x);
	myvector.push_back(max_x);		
	myvector.push_back(min_y);	
	myvector.push_back(max_y);	


	return myvector;
}

bool features::calcula_detectado(vector<Point2f> corners){
	//calculo del angulo

	float diag1,diag2,dif;	
	diag1=sqrt((corners[3].x-corners[0].x)*(corners[3].x-corners[0].x)+
   (corners[3].y-corners[0].y)*(corners[3].y-corners[0].y));
	diag2=sqrt((corners[2].x-corners[1].x)*(corners[2].x-corners[1].x)+
	(corners[2].y-corners[1].y)*(corners[2].y-corners[1].y));
	//printf("diag1: %f\tdiag2: %f\n",diag1,diag2);
	dif=abs(diag1-diag2);	
	bool result = false;
	
	if (dif<40 && diag1>long_diag)
	{
		
		result=true;
	}
	
	return result;


}

void features::DrawBoundingBox(vector<Point2f> corners,Mat img,int inliers, int outliers, string name)
{

	char str[200];
		
	line(img, corners[0] , corners[1] , Scalar(0, 255, 0), 2 );
	line(img, corners[1] , corners[2] , Scalar( 0, 255, 0), 2 );
	line(img, corners[2] , corners[3] , Scalar( 0, 255, 0), 2 );
	line(img, corners[3] , corners[0] , Scalar( 0, 255, 0), 2 );
	
	//calculo del angulo
	float incx,incy,ang;
	  
	incx = corners[0].x-corners[1].x;
	incy = corners[0].y-corners[1].y;	
	ang = atan(incy/incx) * 180/PI*-1;
	Point2f offset( (float)10, 10);
	sprintf(str,"%s ang:%f",name.c_str(),ang);
	putText(img,str,corners[1]+offset,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));

	//Inliers y outliers	
	Point2f offset_in( (float)10, 25);
	sprintf(str,"Inliers: %d",inliers);
	putText(img,str,corners[1]+offset_in,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));
	
	Point2f offset_out( (float)10, 40);
	sprintf(str,"Ouliers: %d",outliers);
	putText(img,str,corners[1]+offset_out,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));	


	imshow(OPENCV_WINDOW, img);
	//mostramos la imagen
	//imshow( "Scene with Bounding Box", img );

}

void drawMultipleObject(int num,char** argv)
{	
	double dstWidth = 0;
	double dstHeight=0;
	Mat dst;
	Mat myImage;
	for (int i=0;i<num;i++)
	{
	myImage=imread(argv[3+i],CV_LOAD_IMAGE_COLOR);

	if(dstHeight<(myImage.rows*escalado_draw))
		dstHeight=myImage.rows*escalado_draw;
	dstWidth = dstWidth + (myImage.cols*escalado_draw);
	}
	dst = Mat(dstHeight, dstWidth, CV_8UC3, cv::Scalar(0,0,0));

	double inicioCols=0;
	for (int i=0;i<num;i++)
	{
	Mat myImage=imread(argv[3+i],CV_LOAD_IMAGE_COLOR);
	resize(myImage, myImage, Size(myImage.cols*escalado_draw,myImage.rows*escalado_draw), 0, 0, CV_INTER_LINEAR);
	myImage.copyTo(dst.rowRange(0, myImage.rows).colRange(inicioCols, inicioCols+myImage.cols));
	inicioCols = myImage.cols+inicioCols;
	}
	
	imshow("Objetos",dst);
	
}

string features::readName(char** argv,int indice)
{
string str(argv[indice+3]);
std::size_t found = str.find_last_of("/\\");
string name = str.substr(found+1);
name.erase(name.length()-4,4);//borra .png
return name;


}

