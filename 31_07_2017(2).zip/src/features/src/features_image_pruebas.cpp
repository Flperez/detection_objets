#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography
#include <time.h>

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <sys/stat.h>

#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265

#define long_diag 50


#define escalado_calculo 0.25
#define escalado_draw 0.25


using namespace cv;
using namespace std;

//
Mat sceneImgColor;
Mat sceneImg;

const string ruta_resultado = "/home/felipe/catkin_ws/src/features/test/resultados";

void showUsage()
{
	printf("\n");
	printf("USO:\n");
	printf("rosrun features2d features2d_node argv[1] argv[2] argv[3] argv[4] ...\n\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[1] -> metodo del Detector: \n");
	printf("0->DenseFeatureDetector\n");
	printf("1->FastFeatureDetector\n");
	printf("2->GFTTDetector\n");
	printf("3->MSER\n");
	printf("4->ORB\n");	
	printf("5->SIFT\n");
	printf("6->StarFeatureDetector\n");
	printf("7->SURF\n");
	printf("8->BRISK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[2] -> metodo del Extractor: \n");
	printf("0->BriefDescriptorExtractor\n");
	printf("1->ORB\n");
	printf("2->SIFT\n");
	printf("3->SURF\n");
	printf("4->BRISK\n");
	printf("5->FREAK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[3] -> ruta al fichero del objeto\n");	
	printf("argv[4] -> ruta al fichero del escenario\n");
	printf("argv[5] -> ruta a la carpeta de resultados\n");	
	exit(1);
}

void DrawBoundingBox(vector<Point2f> corners,int indice,int inliers, int outliers)
{

	char str[200];
		
	line(sceneImgColor, corners[0] , corners[1] , Scalar(0, 255, 0), 2 );
	line(sceneImgColor, corners[1] , corners[2] , Scalar( 0, 255, 0), 2 );
	line(sceneImgColor, corners[2] , corners[3] , Scalar( 0, 255, 0), 2 );
	line(sceneImgColor, corners[3] , corners[0] , Scalar( 0, 255, 0), 2 );
	
	//calculo del angulo
	float incx,incy,ang;
	 
	incx = corners[0].x-corners[1].x;
	incy = corners[0].y-corners[1].y;	
	ang = atan(incy/incx) * 180/PI*-1;
	Point2f offset( (float)10, 10);
	sprintf(str,"Objecto: %d  Ang: %f ",indice,ang);
	putText(sceneImgColor,str,corners[1]+offset,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));

	//Inliers y outliers	
	Point2f offset_in( (float)10, 25);
	sprintf(str,"Inliers: %d",inliers);
	putText(sceneImgColor,str,corners[1]+offset_in,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));
	
	Point2f offset_out( (float)10, 40);
	sprintf(str,"Ouliers: %d",outliers);
	putText(sceneImgColor,str,corners[1]+offset_out,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));	





}

vector<int> limits(vector<Point2f> ptos)
{	vector<int> myvector;
	int min_x=ptos[0].x;int min_y=ptos[0].y;
	int max_x=0;int max_y=0;
	for (int i=0;i<4;i++)
	{		
		if (ptos[i].x<min_x)
		{min_x=ptos[i].x;}
		if (ptos[i].y<min_y)
		{min_y=ptos[i].y;}

		if (ptos[i].x>max_x)
		{max_x=ptos[i].x;}
		if (ptos[i].y>max_y)
		{max_y=ptos[i].y;}
		
	}
	myvector.push_back(min_x);
	myvector.push_back(max_x);		
	myvector.push_back(min_y);	
	myvector.push_back(max_y);	


	return myvector;
}

void borrar_seccion(vector<Point2f> corners)
{
	vector<int> mylimits = limits(corners);

	for (int i = 0; i < sceneImg.rows; i++)
	{
    	for (int j = 0; j < sceneImg.cols; j++)
		{
		  if(j>mylimits.at(0) && j<mylimits.at(1)
			&& i>mylimits.at(2) && i<mylimits.at(3))
			{	//printf("borrando\n");
					sceneImg.at<uchar>(i, j) = 0;
			}

			

		}
}

}



bool calcula_detectado(vector<Point2f> corners){


	float diag1,diag2,dif;	
	diag1=sqrt((corners[3].x-corners[0].x)*(corners[3].x-corners[0].x)+
   (corners[3].y-corners[0].y)*(corners[3].y-corners[0].y));
	diag2=sqrt((corners[2].x-corners[1].x)*(corners[2].x-corners[1].x)+
	(corners[2].y-corners[1].y)*(corners[2].y-corners[1].y));

	dif=abs(diag1-diag2);	
	bool result = false;
	
	if (dif<40 && diag1>long_diag)
	{
		/*if(cont==num)
		{cont=num;result = true;}
		else{cont++;}*/
		result=true;
	}
	
	return result;


}
string getRuta (char **argv, int indice, const string& choose)
{	
	int elemento;
	if (choose == "object")	
		elemento = 2+1;
	else	//choose == "scene"
		elemento = 2+2;
	
	ifstream file(argv[elemento]);
	if(!file)
	{
		cout << "Error no se puede abrir el archivo: " << argv[elemento] << endl;
                exit(0);
	}
	int cont = 0;
	bool fin = false;
	string linea;
 	while( fin == false) 
	{ 
          if(cont == indice) 
             fin = true;
	  getline(file, linea);
	 cont++;
                

	}
	file.close();

	return linea;


}

int numPhotos(char **argv, const string& choose)
{
	int elemento;
	if (choose == "object")	
		elemento = 2+1;
	else	//choose == "scene"
		elemento = 2+2;

	ifstream file(argv[elemento]);
	if(!file)
	{
		cout << "Error no se puede abrir el archivo: " << argv[elemento]<< endl;
                exit(0);
	}
	int cont = 0;
	bool fin = false;
	string linea;
 	while(getline(file, linea)) 
	{
          
	  cont++;
                

	}
	file.close();
	

	return cont;
	

}

Mat image_input(string ruta,int indice, const string& choose)
{
		Mat myImage = imread(ruta,CV_LOAD_IMAGE_COLOR);

		
		if(myImage.empty())
		{
			printf("\nERROR al cargar la imagen:%sd\n",ruta.c_str());
			showUsage();
		}

		if (myImage.rows>640 && myImage.cols>480 && choose == "object")
		{
		//	printf("Las dimensiones de la imagen del objeto son: %dx%d.\n",myImage.cols,myImage.rows);
			resize(myImage, myImage, Size(myImage.cols*escalado_calculo,myImage.rows*escalado_calculo), 0, 0, CV_INTER_LINEAR);
		//	printf("Se ha dimensionado a un 50/100 .\n");
		}

		if (myImage.rows>640 && myImage.cols>480 && choose == "scene")
		{
		//	printf("Las dimensiones de la imagen del objeto son: %dx%d.\n",myImage.cols,myImage.rows);
			resize(myImage, myImage, Size(myImage.cols*.75,myImage.rows*.75), 0, 0, CV_INTER_LINEAR);
		//	printf("Se ha dimensionado a un 50/100 .\n");
		}
	
	return myImage;

}

string readName(string str)
{
	
	size_t found = str.find_last_of("/\\");
	string name = str.substr(found+1);
	name.erase(name.length()-4,4);//borra .png
	return name;


}


int main(int argc, char * argv[])
{ 
	

	if (argc<6 || atoi(argv[1])>8 || atoi(argv[2])>5)
		{printf("ERROR: fallo al introducir los argumentos");showUsage();}

	int numPhotosScene = numPhotos(argv,"scene");
	printf("Numero de fotos de escenarios:%d\n",numPhotosScene);
	int numPhotosObject = numPhotos(argv,"object");
	printf("Numero de fotos de objetos: %d\n",numPhotosObject);
	

	
	int indice;
	for(int i=0;i<numPhotosScene;i++)
	{	//string nameResultado=ruta_resultado;
		string nameResultado(argv[5]);
		
		string ruta =  getRuta (argv,i,"scene");
		string name_scene = readName(ruta);
		nameResultado.append("/");
		nameResultado.append(name_scene);
		nameResultado.append(".png");

		printf("Imagen del escenario: %s\n",ruta.c_str());
		sceneImgColor = image_input(ruta,indice,"scene");
		sceneImg = sceneImgColor.clone();
		cvtColor(sceneImg, sceneImg, CV_BGR2GRAY); //convertimos a blanco y negro
	
		
	
		for (int j=0;j<numPhotosObject;j++)
		{
		
			string ruta =  getRuta (argv,j,"object");
			string name_object = readName(ruta);	
			printf("Imagen del objeto: %s\n",ruta.c_str());
			Mat objectImgColor = image_input(ruta,indice,"object");
			Mat objectImg = objectImgColor.clone();
			cvtColor(objectImg, objectImg, CV_BGR2GRAY); //convertimos a blanco y negro
		
			indice = j;
	
		
			vector<cv::KeyPoint> objectKeypoints;
			vector<cv::KeyPoint> sceneKeypoints;
			Mat objectDescriptors;
			Mat sceneDescriptors;
	
			int Detector = atoi(argv[1]);
			int repetido=0;

			int fin = 0;
			while(!fin)
			{
			
				//DETECTOR
				switch(Detector)
				{
					case 0:	
							{FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
							detector_Dense->detect(objectImg, objectKeypoints);  detector_Dense->detect(sceneImg, sceneKeypoints);
							delete detector_Dense;break;}
		
					case 1:	
							{FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
							detector_Fast->detect(objectImg, objectKeypoints);  detector_Fast->detect(sceneImg, sceneKeypoints);
							delete detector_Fast;break;}


					case 2:	
							{FeatureDetector *detector_GFTT = new GFTTDetector();
							detector_GFTT->detect(objectImg, objectKeypoints);  detector_GFTT->detect(sceneImg, sceneKeypoints);
							delete detector_GFTT;break;}
					case 3: 
							{FeatureDetector *detector_MSER = new MSER();
							detector_MSER->detect(objectImg, objectKeypoints);  detector_MSER->detect(sceneImg, sceneKeypoints);
							delete detector_MSER;break;}

					case 4:	
							{FeatureDetector *detector_ORB =  new ORB();
							detector_ORB->detect(objectImg, objectKeypoints);  detector_ORB->detect(sceneImg, sceneKeypoints);
							delete detector_ORB;break;}
					case 5:	
							{FeatureDetector *detector_SIFT = new SIFT();	
							detector_SIFT->detect(objectImg, objectKeypoints);  detector_SIFT->detect(sceneImg, sceneKeypoints);
							delete detector_SIFT;break;}
					case 6: 
							{FeatureDetector *detector_Star =  new StarFeatureDetector();
							detector_Star->detect(objectImg, objectKeypoints);  detector_Star->detect(sceneImg, sceneKeypoints);
							delete detector_Star;break;}
	
					case 7:	
							{FeatureDetector *detector_SURF = new SURF(600.0);
							detector_SURF->detect(objectImg, objectKeypoints);  detector_SURF->detect(sceneImg, sceneKeypoints);
							delete detector_SURF;break;}

					case 8:	
							{FeatureDetector *detector_BRISK =  new BRISK();
							detector_BRISK->detect(objectImg, objectKeypoints);  detector_BRISK->detect(sceneImg, sceneKeypoints);
							delete detector_BRISK;break;}

				}
			
			
	
				//EXTRACTOR
	
				int Extractor = atoi(argv[2]);
				switch(Extractor)
				{
					case 0: 
							{DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
							extractor_BRIEF->compute(objectImg,objectKeypoints, objectDescriptors);	extractor_BRIEF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
							delete extractor_BRIEF;break;}
					case 1:	
							{DescriptorExtractor *extractor_ORB = new ORB();
							extractor_ORB->compute(objectImg,objectKeypoints, objectDescriptors); extractor_ORB->compute(sceneImg,sceneKeypoints, sceneDescriptors);
							delete extractor_ORB;break;}
					case 2:	
							{DescriptorExtractor *extractor_SIFT = new SIFT();
							extractor_SIFT->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SIFT->compute(sceneImg,sceneKeypoints, sceneDescriptors);
							delete extractor_SIFT;break;}
					case 3:	
							{DescriptorExtractor *extractor_SURF = new SURF(600.0);
							extractor_SURF->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SURF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
							delete extractor_SURF;break;}
					case 4:	
							{DescriptorExtractor *extractor_BRISK = new BRISK();
							extractor_BRISK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_BRISK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
							delete extractor_BRISK;break;}		
					case 5:	
							{DescriptorExtractor *extractor_FREAK = new FREAK();
							extractor_FREAK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_FREAK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
							delete extractor_FREAK;break;}
				}
	
	
	
				//////////////////////////////////////////////////////////////////////////
				// NEAREST NEIGHBOR MATCHING USING FLANN LIBRARY (included in OpenCV)  //
				/////////////////////////////////////////////////////////////////////////
	
	
				Mat results;
				Mat dists;
				int k=2;
				if (objectDescriptors.type()==CV_8U)
				{
					//Descriptores Binarios detectados (ORB o BRIEF)
		
					flann::Index flannIndex(sceneDescriptors, flann::LshIndexParams(12,20,2),cvflann::FLANN_DIST_HAMMING);
		
					flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());

				}
				else
				{
					//asumimos que es CV_32F
					//Creamos Flann KDTree index
					flann::Index flannIndex(sceneDescriptors, flann::KDTreeIndexParams(),cvflann::FLANN_DIST_EUCLIDEAN);

					flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
				}
				//conversion a CV_32F si es necesario
				if (dists.type() == CV_32S)
				{
					Mat temp;
					dists.convertTo(temp,CV_32F);
					dists = temp;	
				}	
	
				////////////////////////////////////////
				//Procesamiento de el resultado del vecino mas cercano
				////////////////////////////////////////
				//Encontramos la correspondencia por NNDR (Nearest Neighbor Distance Ratio)
	
				float nndrRatio = 0.8;
				vector<Point2f> obj,scene;
				vector<int> indexes_1, indexes_2;
				vector<uchar> inlier_mask;


	
				for(unsigned int i=0; i<objectDescriptors.rows;i++)
				{	
					//printf("q=%d dist1=%f dist2=%f\n", i, dists.at<float>(i,0), dists.at<float>(i,1));
					if (results.at<int>(i,0)>=0 && results.at<int>(i,1)>=0 && dists.at<float>(i,0)<=nndrRatio * dists.at<float>(i,1))
					{
					obj.push_back(objectKeypoints.at(i).pt);
					indexes_1.push_back(i);
	

		
					scene.push_back(sceneKeypoints.at(results.at<int>(i,0)).pt);
					indexes_2.push_back(results.at<int>(i,0));

					}
		
				}
	

			  	Mat img_matches(sceneImg.size(),CV_8UC3);
				cvtColor(sceneImg, img_matches, CV_GRAY2RGB);
				vector<KeyPoint> inliers1, inliers2;
				vector<DMatch> inlier_matches;
				vector<Point2f> scene_corners(4);
			
				vector<Point2f> obj_corners(4);
				//find homography
				int nbMatches = 8;
				if(obj.size() >= nbMatches)
				{
				Mat H = findHomography(	obj,scene,RANSAC,1,inlier_mask);

					int inliers=0, outliers=0;
					for(unsigned int k=0; k<obj.size();++k)
						{
							if(inlier_mask.at(k))
							{
								++inliers;
							   
							}
							else
							{
								++outliers;
							}
						}
	
		
				//printf("Inliers=%d Outliers=%d\n", inliers, outliers);
				perspectiveTransform( obj, scene, H);	


				obj_corners[0] = Point(0,0); obj_corners[1] = Point( objectImg.cols, 0 );
				obj_corners[2] = Point( objectImg.cols, objectImg.rows ); obj_corners[3] = Point( 0, objectImg.rows );


				perspectiveTransform( obj_corners, scene_corners, H);
			
				imshow(name_object,objectImgColor);	

			
				if(calcula_detectado(scene_corners)==true)
				{	printf("%s repetido\n",name_object.c_str());
					DrawBoundingBox(scene_corners,indice,inliers,outliers);	
					borrar_seccion(scene_corners);
					repetido++;
				}
				else
				{
					fin =  1;
					printf("Veces que el objeto '%s' se ha repetido: %d\n",name_object.c_str(),repetido);
				}

		

	
				}
				else
				{	fin = 1;
					printf("No hay suficientes coincidencias (%d) para homografia\n", (int)obj.size());
				}	
			
			}//while fin
	
		}//for objeto
		
		imwrite(nameResultado,sceneImgColor);
		imshow( "Scene with Bounding Box",sceneImgColor);
	}//for scene
	
	waitKey(0);

	
	
	return 1;

}


