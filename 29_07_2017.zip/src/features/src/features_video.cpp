#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <ios>
#include <fstream>
#include <stdexcept>
#include <sys/stat.h>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography



#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265
#define num 5
#define escalado 0.5
#define long_diag 50
using namespace cv;
using namespace std;

static const std::string OPENCV_WINDOW = "Scene with Bounding Box";

/*Variables globales*/
Mat objectImg,sceneImg,originalObjectImg,sceneImgColor;	//imagenes del objeto y del esceneario
int Detector, Extractor;	//que detector y extractor queremos
int cont = 0;	//contador de veces que se "detecta" el objeto
bool detectado = false;	//variable para imprimir por pantalla detectado una vez que se detecta el objeto
int flag=0;	//ejecutar 1 vez la entrada de argumentos
int flag_detectado= 0;	//para mostrar por pantalla cuando se detecta el objeto


//para extraer la informacion del entorno y de las imagenes
vector<KeyPoint> objectKeypoints;
vector<KeyPoint> sceneKeypoints;
Mat objectDescriptors;
Mat sceneDescriptors;

//para la introduccion de mas de una imagen para reconocer
int changePhoto = 0; 
char ** g_argv;
int numPhotos;



//

void showUsage()
{
	printf("\n");
	printf("USO:\n");
	printf("rosrun features2d features2d_node argv[1] argv[2] argv[3] ...\n\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[1] -> metodo del Detector: \n");
	printf("0->DenseFeatureDetector\n");
	printf("1->FastFeatureDetector\n");
	printf("2->GFTTDetector\n");
	printf("3->MSER\n");
	printf("4->ORB\n");	
	printf("5->SIFT\n");
	printf("6->StarFeatureDetector\n");
	printf("7->SURF\n");
	printf("8->BRISK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[2] -> metodo del Extractor: \n");
	printf("0->BriefDescriptorExtractor\n");
	printf("1->ORB\n");
	printf("2->SIFT\n");
	printf("3->SURF\n");
	printf("4->BRISK\n");
	printf("5->FREAK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[3] -> Imagen del objeto\n");	
	exit(1);
}

void calcula_descriptor_extractor()
{
	switch(Detector)
	{
		case 0:	
				{
				FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
				detector_Dense->detect(objectImg, objectKeypoints);  detector_Dense->detect(sceneImg, sceneKeypoints);
				delete detector_Dense;
				break;}
		
		case 1:	
				{
				FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
				detector_Fast->detect(objectImg, objectKeypoints);  detector_Fast->detect(sceneImg, sceneKeypoints);
				delete detector_Fast;break;}


		case 2:	
				{
				FeatureDetector *detector_GFTT = new GFTTDetector();
				detector_GFTT->detect(objectImg, objectKeypoints);  detector_GFTT->detect(sceneImg, sceneKeypoints);
				delete detector_GFTT;break;}
		case 3: 
				{
				FeatureDetector *detector_MSER = new MSER();
				detector_MSER->detect(objectImg, objectKeypoints);  detector_MSER->detect(sceneImg, sceneKeypoints);
				delete detector_MSER;break;}

		case 4:	
				{
				FeatureDetector *detector_ORB =  new ORB();
				detector_ORB->detect(objectImg, objectKeypoints);  detector_ORB->detect(sceneImg, sceneKeypoints);
				delete detector_ORB;break;}
		case 5:	
				{
				FeatureDetector *detector_SIFT = new SIFT();	
				detector_SIFT->detect(objectImg, objectKeypoints);  detector_SIFT->detect(sceneImg, sceneKeypoints);
				delete detector_SIFT;
				break;}
		case 6: 
				{
				FeatureDetector *detector_Star =  new StarFeatureDetector();
				detector_Star->detect(objectImg, objectKeypoints);  detector_Star->detect(sceneImg, sceneKeypoints);
				delete detector_Star;break;}
	
		case 7:	
				{
				FeatureDetector *detector_SURF = new SURF(600.0);
				detector_SURF->detect(objectImg, objectKeypoints);  detector_SURF->detect(sceneImg, sceneKeypoints);
				delete detector_SURF;break;}

		case 8:	
				{
				FeatureDetector *detector_BRISK =  new BRISK();
				detector_BRISK->detect(objectImg, objectKeypoints);  detector_BRISK->detect(sceneImg, sceneKeypoints);
				delete detector_BRISK;break;}

	}	

	switch(Extractor)
	{	
		case 0: 
				{
				DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
				extractor_BRIEF->compute(objectImg,objectKeypoints, objectDescriptors);	extractor_BRIEF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRIEF;break;}
		case 1:	
				{
				DescriptorExtractor *extractor_ORB = new ORB();
				extractor_ORB->compute(objectImg,objectKeypoints, objectDescriptors); extractor_ORB->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_ORB;break;}
		case 2:	
				{
				DescriptorExtractor *extractor_SIFT = new SIFT();
				extractor_SIFT->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SIFT->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SIFT;break;}
		case 3:	
				{
				DescriptorExtractor *extractor_SURF = new SURF(600.0);
				extractor_SURF->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SURF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SURF;break;}
		case 4:	
				{
				DescriptorExtractor *extractor_BRISK = new BRISK();
				extractor_BRISK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_BRISK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRISK;break;}		
		case 5:	
				{
				DescriptorExtractor *extractor_FREAK = new FREAK();
				extractor_FREAK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_FREAK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_FREAK;break;}
	}


}


void DrawBoundingBox(vector<Point2f> corners,Mat img, int indice,int inliers, int outliers)
{

	char str[200];
		
	line(img, corners[0] , corners[1] , Scalar(0, 255, 0), 2 );
	line(img, corners[1] , corners[2] , Scalar( 0, 255, 0), 2 );
	line(img, corners[2] , corners[3] , Scalar( 0, 255, 0), 2 );
	line(img, corners[3] , corners[0] , Scalar( 0, 255, 0), 2 );
	
	//calculo del angulo
	float incx,incy,ang;
	  
	incx = corners[0].x-corners[1].x;
	incy = corners[0].y-corners[1].y;	
	ang = atan(incy/incx) * 180/PI*-1;
	Point2f offset( (float)10, 10);
	sprintf(str,"Objecto%d ang:%f",indice,ang);
	putText(img,str,corners[1]+offset,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));

	//Inliers y outliers	
	Point2f offset_in( (float)10, 25);
	sprintf(str,"Inliers: %d",inliers);
	putText(img,str,corners[1]+offset_in,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));
	
	Point2f offset_out( (float)10, 40);
	sprintf(str,"Ouliers: %d",outliers);
	putText(img,str,corners[1]+offset_out,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));	



	//mostramos la imagen
	imshow( "Scene with Bounding Box", img );

}

bool calcula_detectado(vector<Point2f> corners){
	//calculo del angulo
	//float incx,incy,ang;
	float diag1,diag2,dif;	
	diag1=sqrt((corners[3].x-corners[0].x)*(corners[3].x-corners[0].x)+
   (corners[3].y-corners[0].y)*(corners[3].y-corners[0].y));
	diag2=sqrt((corners[2].x-corners[1].x)*(corners[2].x-corners[1].x)+
	(corners[2].y-corners[1].y)*(corners[2].y-corners[1].y));
	//printf("diag1: %f\tdiag2: %f\n",diag1,diag2);
	dif=abs(diag1-diag2);	
	bool result = false;
	
	if (dif<40 && diag1>long_diag)
	{
		/*if(cont==num)
		{cont=num;result = true;}
		else{cont++;}*/
		result=true;
	}
	else
	{flag_detectado = 0;}
	/*else
		{cont=0;
		flag_detectado = 0;}
	
	printf("cont: %d\n",cont);
	*/
	return result;


}

vector<int> limits(vector<Point2f> ptos)
{	vector<int> myvector;
	int min_x=ptos[0].x;int min_y=ptos[0].y;
	int max_x=0;int max_y=0;
	for (int i=0;i<4;i++)
	{		
		if (ptos[i].x<min_x)
		{min_x=ptos[i].x;}
		if (ptos[i].y<min_y)
		{min_y=ptos[i].y;}

		if (ptos[i].x>max_x)
		{max_x=ptos[i].x;}
		if (ptos[i].y>max_y)
		{max_y=ptos[i].y;}
		
	}
	myvector.push_back(min_x);
	myvector.push_back(max_x);		
	myvector.push_back(min_y);	
	myvector.push_back(max_y);	


	return myvector;
}

void borrar_seccion(vector<Point2f> corners)
{
	vector<int> mylimits = limits(corners);

	for (int i = 0; i < sceneImg.rows; i++)
	{
    	for (int j = 0; j < sceneImg.cols; j++)
		{
		  if(j>mylimits.at(0) && j<mylimits.at(1)
			&& i>mylimits.at(2) && i<mylimits.at(3))
			{	//printf("borrando\n");
					sceneImg.at<uchar>(i, j) = 0;
			}

			

		}
	}

}

Mat image_input(char** argv,int indice)
{
	Mat myImage = imread(argv[3+indice],CV_LOAD_IMAGE_COLOR);
	char str[10];
		
		if(myImage.empty())
		{
			printf("\nERROR al cargar la imagen\n");
			showUsage();
		}

		if (myImage.rows>640 && myImage.cols>480)
		{
		//	printf("Las dimensiones de la imagen del objeto son: %dx%d.\n",myImage.cols,myImage.rows);
			resize(myImage, myImage, Size(myImage.cols*escalado,myImage.rows*escalado), 0, 0, CV_INTER_LINEAR);
		//	printf("Se ha dimensionado a un 50/100 .\n");
		}
	sprintf(str,"Objeto%d",indice);
	imshow(str,myImage);
	return myImage;

}



class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;


public:
  ImageConverter()
    : it_(nh_)
      
	 
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/usb_cam/image_raw", 1,
      &ImageConverter::imageCb, this);


    namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    destroyWindow(OPENCV_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
    

	////////////////////////////////////////////////////////////////////////
	sceneImgColor = cv_ptr->image;
	sceneImg = sceneImgColor.clone();
	cvtColor(sceneImg, sceneImg, CV_BGR2GRAY); //convertimos a blanco y negro

	for (int i=0;i<numPhotos;i++)
	{
	
		//if(!changePhoto)
		//{	changePhoto = 1;
		originalObjectImg = image_input(g_argv,i);
		objectImg = originalObjectImg.clone();
		cvtColor(objectImg, objectImg, CV_BGR2GRAY); //convertimos a blanco y negro
		//}
		int fin = 0;
		int indice=i;
		int repetido = 0;
		while(!fin)
		{
			//calculamos objectDescriptor y sceneDescriptor
			calcula_descriptor_extractor();
		





			/////////////////////////////////////////////////////////////////////////
			// NEAREST NEIGHBOR MATCHING USING FLANN LIBRARY (included in OpenCV)  //
			/////////////////////////////////////////////////////////////////////////
			Mat results;
			Mat dists;
			std::vector<std::vector<cv::DMatch> > matches;
	
			int k=2;
			bool useBFMatcher = false; // SET TO TRUE TO USE BRUTE FORCE MATCHER
			if (objectDescriptors.type()==CV_8U)
			{
				if(useBFMatcher)
					{
						cv::BFMatcher matcher(cv::NORM_HAMMING); // use cv::NORM_HAMMING2 for ORB descriptor with WTA_K == 3 or 4 (see ORB constructor)
						matcher.knnMatch(objectDescriptors, sceneDescriptors, matches, k);
				}		
	
				else
				{
				//// Binary descriptors detected (from ORB, Brief, BRISK, FREAK)
				//printf("CV_8U\n");
				flann::Index flannIndex(sceneDescriptors, flann::LshIndexParams(12,20,2),cvflann::FLANN_DIST_HAMMING);
		
				flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
				}

			}
			else
			{
				//asumimos que es CV_32F
				//Creamos Flann KDTree index
		
				if(useBFMatcher)
					{
						cv::BFMatcher matcher(cv::NORM_L2);
						matcher.knnMatch(objectDescriptors, sceneDescriptors, matches, k);
				}
				else
				{
				//printf("CV_32F\n");
				flann::Index flannIndex(sceneDescriptors, flann::KDTreeIndexParams(),cvflann::FLANN_DIST_EUCLIDEAN);

				flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
				}
			}
			//conversion a CV_32F si es necesario
			if (dists.type() == CV_32S)
			{
				//printf("CV_32S\n");
				Mat temp;
				dists.convertTo(temp,CV_32F);
				dists = temp;	
			}	
	
			////////////////////////////////////////
			//Procesamiento de el resultado del vecino mas cercano
			////////////////////////////////////////
			//Encontramos la correspondencia por NNDR (Nearest Neighbor Distance Ratio)
	
			float nndrRatio = 0.8;
			vector<Point2f> obj,scene;
			vector<int> indexes_1, indexes_2;
			vector<uchar> inlier_mask;

			if(useBFMatcher)
			{
				for(unsigned int i=0; i<matches.size(); ++i)
						{
							// Apply NNDR
							//printf("q=%d dist1=%f dist2=%f\n", matches.at(i).at(0).queryIdx, matches.at(i).at(0).distance, matches.at(i).at(1).distance);
							if(matches.at(i).size() == 2 &&
							   matches.at(i).at(0).distance <= nndrRatio * matches.at(i).at(1).distance)
							{
								obj.push_back(objectKeypoints.at(matches.at(i).at(0).queryIdx).pt);
								indexes_1.push_back(matches.at(i).at(0).queryIdx);

								scene.push_back(sceneKeypoints.at(matches.at(i).at(0).trainIdx).pt);
								indexes_2.push_back(matches.at(i).at(0).trainIdx);
							}
			}
		
			}
			else
			{
			for(unsigned int i=0; i<objectDescriptors.rows;i++)
			{	
				//printf("q=%d dist1=%f dist2=%f\n", i, dists.at<float>(i,0), dists.at<float>(i,1));
				if (results.at<int>(i,0)>=0 && results.at<int>(i,1)>=0 && dists.at<float>(i,0)<=nndrRatio * dists.at<float>(i,1))
				{
				obj.push_back(objectKeypoints.at(i).pt);
				indexes_1.push_back(i);
	

		
				scene.push_back(sceneKeypoints.at(results.at<int>(i,0)).pt);
				indexes_2.push_back(results.at<int>(i,0));

				}
		
			}	
			}
	
		


			vector<KeyPoint> inliers1, inliers2;
			vector<DMatch> inlier_matches;

			int nbMatches = 8;
			if(obj.size() >= nbMatches)
			{

				Mat H = findHomography(	obj,scene,RANSAC,1,	inlier_mask);
				int inliers=0, outliers=0;
				for(unsigned int k=0; k<obj.size();++k)
					{
						if(inlier_mask.at(k))
						{
							inliers++;
						   
						}
						else
						{
							outliers++;
						}
					}
	
				//printf("inliers: %d\toutliers: %d\n",inliers,outliers);
				perspectiveTransform( obj, scene, H);	


				vector<Point2f> obj_corners(4);
				obj_corners[0] = Point(0,0); obj_corners[1] = Point( objectImg.cols, 0 );
				obj_corners[2] = Point( objectImg.cols, objectImg.rows ); 
				obj_corners[3] = Point( 0, objectImg.rows );
				vector<Point2f> scene_corners(4);

				perspectiveTransform( obj_corners, scene_corners, H);

			
		
			
		
	
				if(calcula_detectado(scene_corners)==true) //Detectado
				{
					printf("objeto%d repetido\n",indice);
					DrawBoundingBox(scene_corners,sceneImgColor,indice,inliers,outliers);
					borrar_seccion(scene_corners);
					repetido++;
					if (flag_detectado==0)	
					{	
				
						ROS_INFO("Detectado\n");
						flag_detectado=1;		
					}
				}
				else
				{
					fin = 1;	
					printf("Veces que el objeto%d se ha repetido: %d\n",indice,repetido);	
				}
	
		
			}
			else
			{
				fin = 1;
				printf("No hay suficientes coincidencias (%d) para homografia\n", (int)obj.size());		
			}
		

		}
    }

	
	
	// Update GUI Window
    imshow(OPENCV_WINDOW, sceneImgColor);
	//imshow("objeto",originalObjectImg);
	waitKey(1);

	

	
  }
};




int main(int argc, char** argv)
{
	//inicializacion
	ros::init(argc, argv, "features");
	
	//ejecutar la primera vez	
	if(!flag)
	{	
		if (argc<4 || atoi(argv[1])>8 || atoi(argv[2])>5)
			{showUsage();}
		g_argv = argv;
		numPhotos = argc-3;
		printf("Numero de fotos: %d.\n",numPhotos);
		Detector = atoi(argv[1]); Extractor = atoi(argv[2]);		
		flag= 1;
	}
	
	//clase de ImageConverter
	ImageConverter ic;
	ros::spin();	
	return 0;
}




