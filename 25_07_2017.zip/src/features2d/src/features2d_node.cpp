#include <stdio.h>
#include <stdlib.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography
#include <math.h>


#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif

#define PI 3.14159265
#define num 7

using namespace cv;
using namespace std;

void showUsage()
{
	printf("\n");
	printf("USO:\n");
	printf("rosrun sift sift_node argv[1] argv[2] argv[3] \n\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[1] -> Imagen del objeto\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[2] -> metodo del Detector: \n");
	printf("0->DenseFeatureDetector\n");
	printf("1->FastFeatureDetector\n");
	printf("2->GFTTDetector\n");
	printf("3->MSER\n");
	printf("4->ORB\n");	
	printf("5->SIFT\n");
	printf("6->StarFeatureDetector\n");
	printf("7->SURF\n");
	printf("8->BRISK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[3] -> metodo del Extractor: \n");
	printf("0->BriefDescriptorExtractor\n");
	printf("1->ORB\n");
	printf("2->SIFT\n");
	printf("3->SURF\n");
	printf("4->BRISK\n");
	printf("5->FREAK\n");
	printf("------------------------------------------------------\n\n");	
	exit(1);
}



float calcula_dif(vector<Point2f> corners){
	//calculo del angulo
	//float incx,incy,ang;
	float diag1,diag2,dif;	
	diag1=sqrt((corners[3].x-corners[0].x)*(corners[3].x-corners[0].x)+
   (corners[3].y-corners[0].y)*(corners[3].y-corners[0].y));
	diag2=sqrt((corners[2].x-corners[1].x)*(corners[2].x-corners[1].x)+
	(corners[2].y-corners[1].y)*(corners[2].y-corners[1].y));

	
	dif=abs(diag1-diag2);
	//printf("diag1: %f\tdiag2: %f\tDiferencia: %f\n",diag1,diag2,dif);
	return dif;

}

void DrawBoundingBox(vector<Point2f> corners,Mat img,int inliers, int outliers)
{

	char str[200];
		
	line(img, corners[0] , corners[1] , Scalar(0, 255, 0), 2 );
	line(img, corners[1] , corners[2] , Scalar( 0, 255, 0), 2 );
	line(img, corners[2] , corners[3] , Scalar( 0, 255, 0), 2 );
	line(img, corners[3] , corners[0] , Scalar( 0, 255, 0), 2 );
	
	//calculo del angulo
	float incx,incy,ang;
	 
	incx = corners[0].x-corners[1].x;
	incy = corners[0].y-corners[1].y;	
	ang = atan(incy/incx) * 180/PI*-1;
	Point2f offset( (float)10, 10);
	sprintf(str,"Ang: %f ",ang);
	putText(img,str,corners[1]+offset,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));

	//Inliers y outliers	
	Point2f offset_in( (float)10, 25);
	sprintf(str,"Inliers: %d      Ouliers: %d",inliers,outliers);
	putText(img,str,corners[1]+offset_in,FONT_HERSHEY_PLAIN, 1,  Scalar(0,0,255,255));
	
	//mostramos la imagen
	imshow( "Scene with Bounding Box", img );

}



int main(int argc, char * argv[])
{

	if (argc<4 || atoi(argv[2])>8 || atoi(argv[3])>5)
		{showUsage();}
	

	Mat objectImg = imread(argv[1],CV_LOAD_IMAGE_GRAYSCALE);
	Mat sceneImg; 
	
	if(objectImg.empty())
    {
        printf("\nERROR al cargar la imagen\n");
        showUsage();
    }

	vector<cv::KeyPoint> objectKeypoints;
	vector<cv::KeyPoint> sceneKeypoints;
	Mat objectDescriptors;
	Mat sceneDescriptors;
	
	int Detector = atoi(argv[2]);
	
	float max_dist=0;
	int cont = 0;
	int detectado = 0;
	VideoCapture cap(-1); // open the default camera
	
    while ((cvWaitKey(10) & 255) != 27) {
	cap >> sceneImg;
	cvtColor(sceneImg, sceneImg, CV_BGR2GRAY); // Work on grayscale images as trained

	
	//DETECTOR
	switch(Detector)
	{
		case 0:	
				{FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
				detector_Dense->detect(objectImg, objectKeypoints);  detector_Dense->detect(sceneImg, sceneKeypoints);
				delete detector_Dense;break;}
		
		case 1:	
				{FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
				detector_Fast->detect(objectImg, objectKeypoints);  detector_Fast->detect(sceneImg, sceneKeypoints);
				delete detector_Fast;break;}


		case 2:	
				{FeatureDetector *detector_GFTT = new GFTTDetector();
				detector_GFTT->detect(objectImg, objectKeypoints);  detector_GFTT->detect(sceneImg, sceneKeypoints);
				delete detector_GFTT;break;}
		case 3: 
				{FeatureDetector *detector_MSER = new MSER();
				detector_MSER->detect(objectImg, objectKeypoints);  detector_MSER->detect(sceneImg, sceneKeypoints);
				delete detector_MSER;break;}

		case 4:	
				{FeatureDetector *detector_ORB =  new ORB();
				detector_ORB->detect(objectImg, objectKeypoints);  detector_ORB->detect(sceneImg, sceneKeypoints);
				delete detector_ORB;break;}
		case 5:	
				{FeatureDetector *detector_SIFT = new SIFT();	
				detector_SIFT->detect(objectImg, objectKeypoints);  detector_SIFT->detect(sceneImg, sceneKeypoints);
				delete detector_SIFT;break;}
		case 6: 
				{FeatureDetector *detector_Star =  new StarFeatureDetector();
				detector_Star->detect(objectImg, objectKeypoints);  detector_Star->detect(sceneImg, sceneKeypoints);
				delete detector_Star;break;}
	
		case 7:	
				{FeatureDetector *detector_SURF = new SURF(600.0);
				detector_SURF->detect(objectImg, objectKeypoints);  detector_SURF->detect(sceneImg, sceneKeypoints);
				delete detector_SURF;break;}

		case 8:	
				{FeatureDetector *detector_BRISK =  new BRISK();
				detector_BRISK->detect(objectImg, objectKeypoints);  detector_BRISK->detect(sceneImg, sceneKeypoints);
				delete detector_BRISK;break;}

	}
	
	

	
	
	
	

	//DescriptorExtractor *extractor= new SIFT(); 
	
	//EXTRACTOR
	
	int Extractor = atoi(argv[3]);
	switch(Extractor)
	{
		case 0: 
				{DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
				extractor_BRIEF->compute(objectImg,objectKeypoints, objectDescriptors);	extractor_BRIEF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRIEF;break;}
		case 1:	
				{DescriptorExtractor *extractor_ORB = new ORB();
				extractor_ORB->compute(objectImg,objectKeypoints, objectDescriptors); extractor_ORB->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_ORB;break;}
		case 2:	
				{DescriptorExtractor *extractor_SIFT = new SIFT();
				extractor_SIFT->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SIFT->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SIFT;break;}
		case 3:	
				{DescriptorExtractor *extractor_SURF = new SURF(600.0);
				extractor_SURF->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SURF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SURF;break;}
		case 4:	
				{DescriptorExtractor *extractor_BRISK = new BRISK();
				extractor_BRISK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_BRISK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRISK;break;}		
		case 5:	
				{DescriptorExtractor *extractor_FREAK = new FREAK();
				extractor_FREAK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_FREAK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_FREAK;break;}
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////
	// NEAREST NEIGHBOR MATCHING USING FLANN LIBRARY (included in OpenCV)  //
	/////////////////////////////////////////////////////////////////////////
	
	
	Mat results;
	Mat dists;
	int k=2;
	if (objectDescriptors.type()==CV_8U)
	{
		//Descriptores Binarios detectados (ORB o BRIEF)
		
		flann::Index flannIndex(sceneDescriptors, flann::LshIndexParams(12,20,2),cvflann::FLANN_DIST_HAMMING);
		
		flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());

	}
	else
	{
		//asumimos que es CV_32F
		//Creamos Flann KDTree index
		flann::Index flannIndex(sceneDescriptors, flann::KDTreeIndexParams(),cvflann::FLANN_DIST_EUCLIDEAN);

		flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
	}
	//conversion a CV_32F si es necesario
	if (dists.type() == CV_32S)
	{
		Mat temp;
		dists.convertTo(temp,CV_32F);
		dists = temp;	
	}	
	
	////////////////////////////////////////
	//Procesamiento de el resultado del vecino mas cercano
	////////////////////////////////////////
	//Encontramos la correspondencia por NNDR (Nearest Neighbor Distance Ratio)
	
	float nndrRatio = 0.8;
	vector<Point2f> obj,scene;
	vector<int> indexes_1, indexes_2;
	vector<uchar> inlier_mask;


	
	for(unsigned int i=0; i<objectDescriptors.rows;i++)
	{	
		//printf("q=%d dist1=%f dist2=%f\n", i, dists.at<float>(i,0), dists.at<float>(i,1));
		if (results.at<int>(i,0)>=0 && results.at<int>(i,1)>=0 && dists.at<float>(i,0)<=nndrRatio * dists.at<float>(i,1))
		{
		obj.push_back(objectKeypoints.at(i).pt);
		indexes_1.push_back(i);
	

		
		scene.push_back(sceneKeypoints.at(results.at<int>(i,0)).pt);
		indexes_2.push_back(results.at<int>(i,0));

		}
		
	}
	

    Mat img_matches(sceneImg.size(),CV_8UC3);
    cvtColor(sceneImg, img_matches, CV_GRAY2RGB);
	vector<KeyPoint> inliers1, inliers2;
    vector<DMatch> inlier_matches;
	
	//find homography
	int nbMatches = 8;
	if(obj.size() >= nbMatches)
	{
	Mat H = findHomography(	obj,
							scene,
							RANSAC,
							1,
							inlier_mask);

		int inliers=0, outliers=0;
		for(unsigned int k=0; k<obj.size();++k)
			{
				if(inlier_mask.at(k))
				{
					++inliers;
				   
				}
				else
				{
					++outliers;
				}
			}
	
		
	//printf("Inliers=%d Outliers=%d\n", inliers, outliers);
	perspectiveTransform( obj, scene, H);	


	  vector<Point2f> obj_corners(4);
	  obj_corners[0] = Point(0,0); obj_corners[1] = Point( objectImg.cols, 0 );
	  obj_corners[2] = Point( objectImg.cols, objectImg.rows ); obj_corners[3] = Point( 0, objectImg.rows );
	  vector<Point2f> scene_corners(4);

  	  perspectiveTransform( obj_corners, scene_corners, H);

	  
  
 
	/*
	printf("\nBounding box:\n");
	printf("(0,0)->(%f,%f)\n",scene_corners[0].x,scene_corners[0].y);
	printf("(0,1)->(%f,%f)\n",scene_corners[1].x,scene_corners[1].y);
	printf("(1,0)->(%f,%f)\n",scene_corners[2].x,scene_corners[2].y);
	printf("(1,1)->(%f,%f)\n",scene_corners[3].x,scene_corners[3].y);
	*/

//	waitKey(0);
	


	float diff=calcula_dif(scene_corners);	
	
	
	if (diff<40)
	{
		if(cont==num)
			{cont=num;}
		else{cont++;}}
	else
		{cont=0;
		detectado = 0;}
	
	if(cont==num) //Detectado
	{
		
		DrawBoundingBox(scene_corners,img_matches,inliers,outliers);
		if (detectado==0)	
		{
			printf("Detectado\n");
			detectado=1;		
		}
	}
	
	else
	{//printf("cont: %d\n",cont);
		
		imshow("Scene with Bounding Box", img_matches );
	}	
	imshow("Objecto",objectImg);
	}
	else
	{
		printf("No hay suficientes coincidencias (%d) para homografia\n", (int)obj.size());
	}	
	
	 
	}
return 1;
}
