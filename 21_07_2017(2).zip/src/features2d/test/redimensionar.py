#!/usr/bin/python
import Image
import os

inputFolder = '/home/felipe/catkin_ws/src/features/test'
outputFolder = '/home/felipe/catkin_ws/src/features'



def run():

    #List all files
    fileList = os.listdir(inputFolder)
    #Select only files that end with .png
    imagesList = filter(lambda element: '.jpg' in element, fileList)

    for filename in imagesList:
        imagepath = inputFolder + '/' + filename
        outputpath = outputFolder+'/'+filename

        if os.path.exists(outputpath):
            print 'Features for ' + imagepath + '. Delete the file if you want to replace.'
            continue

        print 'Redimensionando: ' + imagepath

        image = Image.open(imagepath)
        #Read the image as bytes (pixels with values 0-255)
        
		# adjust width and height to your needs

        width = 64
        height = 128
	
        im = image.resize((width, height), Image.BILINEAR)
        		

        #Save the features to a file
        outputFile = open(outputpath, "wb")
        im.save(filename)
        outputFile.close()














if __name__ == '__main__':
    run()
