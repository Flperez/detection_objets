#include <stdio.h>
#include <stdlib.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp> // for homography


#include <opencv2/opencv_modules.hpp>

#ifdef HAVE_OPENCV_NONFREE
  #if CV_MAJOR_VERSION == 2 && CV_MINOR_VERSION >=4
  #include <opencv2/nonfree/gpu.hpp>
  #include <opencv2/nonfree/features2d.hpp>
  #endif
#endif
#ifdef HAVE_OPENCV_XFEATURES2D
  #include <opencv2/xfeatures2d.hpp>
  #include <opencv2/xfeatures2d/cuda.hpp>
#endif




void showUsage()
{
	printf("\n");
	printf("USO:\n");
	printf("rosrun sift sift_node argv[1] argv[2] argv[3] argv[4] \n\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[1] -> Imagen del objeto\n");
	printf("argv[2] -> Imagen de la escena\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[3] -> metodo del Detector: \n");
	printf("0->DenseFeatureDetector\n");
	printf("1->FastFeatureDetector\n");
	printf("2->GFTTDetector\n");
	printf("3->MSER\n");
	printf("4->ORB\n");	
	printf("5->SIFT\n");
	printf("6->StarFeatureDetector\n");
	printf("7->BRISK\n");
	printf("------------------------------------------------------\n\n");
	printf("argv[4] -> metodo del Extractor: \n");
	printf("0->BriefDescriptorExtractor\n");
	printf("1->ORB\n");
	printf("2->SIFT\n");
	printf("3->SURF\n");
	printf("4->BRISK\n");
	printf("5->FREAK\n");
	printf("------------------------------------------------------\n\n");	
	exit(1);
}

using namespace cv;
using namespace std;

int main(int argc, char * argv[])
{

	if (argc<5 || atoi(argv[3])>8 || atoi(argv[4])>5)
		{showUsage();}
	

	Mat objectImg = imread(argv[1],CV_LOAD_IMAGE_GRAYSCALE);
	Mat sceneImg = imread(argv[2],CV_LOAD_IMAGE_GRAYSCALE);
	
	if(objectImg.empty() || sceneImg.empty())
    {
        printf("ERROR al cargar las imagenes\n");
        showUsage();
    }

	vector<cv::KeyPoint> objectKeypoints;
	vector<cv::KeyPoint> sceneKeypoints;
	Mat objectDescriptors;
	Mat sceneDescriptors;
	
	int Detector = atoi(argv[3]);
	

	

	
	//DETECTOR
	switch(Detector)
	{
		case 0:	
				{FeatureDetector *detector_Dense 	=  	new DenseFeatureDetector();
				detector_Dense->detect(objectImg, objectKeypoints);  detector_Dense->detect(sceneImg, sceneKeypoints);
				delete detector_Dense;break;}
		
		case 1:	
				{FeatureDetector *detector_Fast	=  	new FastFeatureDetector();
				detector_Fast->detect(objectImg, objectKeypoints);  detector_Fast->detect(sceneImg, sceneKeypoints);
				delete detector_Fast;break;}


		case 2:	
				{FeatureDetector *detector_GFTT = new GFTTDetector();
				detector_GFTT->detect(objectImg, objectKeypoints);  detector_GFTT->detect(sceneImg, sceneKeypoints);
				delete detector_GFTT;break;}
		case 3: 
				{FeatureDetector *detector_MSER = new MSER();
				detector_MSER->detect(objectImg, objectKeypoints);  detector_MSER->detect(sceneImg, sceneKeypoints);
				delete detector_MSER;break;}

		case 4:	
				{FeatureDetector *detector_ORB =  new ORB();
				detector_ORB->detect(objectImg, objectKeypoints);  detector_ORB->detect(sceneImg, sceneKeypoints);
				delete detector_ORB;break;}
		case 5:	
				{FeatureDetector *detector_SIFT = new SIFT();	
				detector_SIFT->detect(objectImg, objectKeypoints);  detector_SIFT->detect(sceneImg, sceneKeypoints);
				delete detector_SIFT;break;}
		case 6: 
				{FeatureDetector *detector_Star =  new StarFeatureDetector();
				detector_Star->detect(objectImg, objectKeypoints);  detector_Star->detect(sceneImg, sceneKeypoints);
				delete detector_Star;break;}
	
		case 7:	
				{FeatureDetector *detector_SURF = new SURF(600.0);
				detector_SURF->detect(objectImg, objectKeypoints);  detector_SURF->detect(sceneImg, sceneKeypoints);
				delete detector_SURF;break;}

		case 8:	
				{FeatureDetector *detector_BRISK =  new BRISK();
				detector_BRISK->detect(objectImg, objectKeypoints);  detector_BRISK->detect(sceneImg, sceneKeypoints);
				delete detector_BRISK;break;}

	}
	
	

	
	
	
	

	//DescriptorExtractor *extractor= new SIFT(); 
	
	//EXTRACTOR
	
	int Extractor = atoi(argv[4]);
	switch(Extractor)
	{
		case 0: 
				{DescriptorExtractor *extractor_BRIEF = new BriefDescriptorExtractor();
				extractor_BRIEF->compute(objectImg,objectKeypoints, objectDescriptors);	extractor_BRIEF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRIEF;break;}
		case 1:	
				{DescriptorExtractor *extractor_ORB = new ORB();
				extractor_ORB->compute(objectImg,objectKeypoints, objectDescriptors); extractor_ORB->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_ORB;break;}
		case 2:	
				{DescriptorExtractor *extractor_SIFT = new SIFT();
				extractor_SIFT->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SIFT->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SIFT;break;}
		case 3:	
				{DescriptorExtractor *extractor_SURF = new SURF(600.0);
				extractor_SURF->compute(objectImg,objectKeypoints, objectDescriptors); extractor_SURF->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_SURF;break;}
		case 4:	
				{DescriptorExtractor *extractor_BRISK = new BRISK();
				extractor_BRISK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_BRISK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_BRISK;break;}		
		case 5:	
				{DescriptorExtractor *extractor_FREAK = new FREAK();
				extractor_FREAK->compute(objectImg,objectKeypoints, objectDescriptors); extractor_FREAK->compute(sceneImg,sceneKeypoints, sceneDescriptors);
				delete extractor_FREAK;break;}
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////
	// NEAREST NEIGHBOR MATCHING USING FLANN LIBRARY (included in OpenCV)  //
	/////////////////////////////////////////////////////////////////////////
	
	
	Mat results;
	Mat dists;
	int k=2;
	if (objectDescriptors.type()==CV_8U)
	{
		//Descriptores Binarios detectados (ORB o BRIEF)
		
		flann::Index flannIndex(sceneDescriptors, flann::LshIndexParams(12,20,2),cvflann::FLANN_DIST_HAMMING);
		
		flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());

	}
	else
	{
		//asumimos que es CV_32F
		//Creamos Flann KDTree index
		flann::Index flannIndex(sceneDescriptors, flann::KDTreeIndexParams(),cvflann::FLANN_DIST_EUCLIDEAN);

		flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
	}
	//conversion a CV_32F si es necesario
	if (dists.type() == CV_32S)
	{
		Mat temp;
		dists.convertTo(temp,CV_32F);
		dists = temp;	
	}	
	
	////////////////////////////////////////
	//Procesamiento de el resultado del vecino mas cercano
	////////////////////////////////////////
	//Encontramos la correspondencia por NNDR (Nearest Neighbor Distance Ratio)
	
	float nndrRatio = 0.8;
	vector<Point2f> mpts_1,mpts_2;
	vector<int> indexes_1, indexes_2;
	vector<uchar> outlier_mask;
	
	for(unsigned int i=0; i<objectDescriptors.rows;i++)
	{	
		//printf("q=%d dist1=%f dist2=%f\n", i, dists.at<float>(i,0), dists.at<float>(i,1));
		if (results.at<int>(i,0)>=0 && results.at<int>(i,1)>=0 && dists.at<float>(i,0)<=nndrRatio * dists.at<float>(i,1))
		{
		mpts_1.push_back(objectKeypoints.at(i).pt);
		indexes_1.push_back(i);
		
		mpts_2.push_back(sceneKeypoints.at(results.at<int>(i,0)).pt);
		indexes_2.push_back(results.at<int>(i,0));
		}
		
	}
	
	Mat img_matches;

	//find homography
	int nbMatches = 8;
	if(mpts_1.size() >= nbMatches)
	{
	Mat H = findHomography(mpts_1,
							mpts_2,
							RANSAC);

	//-- Get the corners from the image_1 ( the object to be "detected" )
	  std::vector<Point2f> obj_corners(4);
	  obj_corners[0] = cvPoint(0,0); obj_corners[1] = cvPoint( objectImg.cols, 0 );
	  obj_corners[2] = cvPoint( objectImg.cols, objectImg.rows ); obj_corners[3] = cvPoint( 0, objectImg.rows );
	  
	  std::vector<Point2f> scene_corners(4);

	  perspectiveTransform( obj_corners, scene_corners, H);

	  //-- Draw lines between the corners (the mapped object in the scene - image_2 )
	  line( img_matches, scene_corners[0] + Point2f( objectImg.cols, 0), scene_corners[1] + Point2f( objectImg.cols, 0), Scalar(0, 255, 0), 4 );
	  line( img_matches, scene_corners[1] + Point2f( objectImg.cols, 0), scene_corners[2] + Point2f( objectImg.cols, 0), Scalar( 0, 255, 0), 4 );
	  line( img_matches, scene_corners[2] + Point2f( objectImg.cols, 0), scene_corners[3] + Point2f( objectImg.cols, 0), Scalar( 0, 255, 0), 4 );
	  line( img_matches, scene_corners[3] + Point2f( objectImg.cols, 0), scene_corners[0] + Point2f( objectImg.cols, 0), Scalar( 0, 255, 0), 4 );


	  //-- Show detected matches
	  imshow( "Good Matches & Object detection", img_matches );

	  waitKey(0);
		
	}
	else
	{
		printf("No hay suficientes coincidencias (%d) para homografia\n", (int)mpts_1.size());
	}	

	
	

  return 0;
	

	return 1;

}
