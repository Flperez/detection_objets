#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>
#include <boost/foreach.hpp>
#include "coordenadas/dat.h"





float x3D,y3D,z3D;
float u,v;

typedef pcl::PointCloud<pcl::PointXYZ> PointCloud;




float x[217088];
float y[512*424];
float z[512*424];

void callback(const PointCloud::ConstPtr& msg)
{

	

	for(int j=0;j<msg->width;j++)
		{
			for(int k=0;k<msg->height;k++)
			{
			int i = (j) + (k)*msg->width;

			// 3D coordinates from point cloud 
			x[i] = (float)msg->points[i].x;
			y[i] = (float)msg->points[i].y;
			z[i] = (float)msg->points[i].z;
			//printf("x3D:%f y3D:%f z3D: %f \n",x3D,y3D,z3D);
			}
		}
	
}

bool conversion(coordenadas::dat::Request &req, coordenadas::dat::Response &res) 
{
	
	u=req.uv[0];
	v=req.uv[1];
	res.xyz.resize(3);
	

	printf("Ha llegado (%f,%f)\n",u,v);
	
	int i = (u) + (v)*512;
	res.xyz[0]=x[i];
	res.xyz[1]=y[i];
	res.xyz[2]=z[i];	



	printf("x3D:%f y3D:%f z3D: %f \n",res.xyz[0],res.xyz[1],res.xyz[2]);
	
	
  
  return true;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "Coordenadas_xyz");
  ros::NodeHandle nh,n;
  
	ros::Subscriber sub = nh.subscribe<PointCloud>("/kinect2/sd/points", 1, callback);

  ros::ServiceServer service = n.advertiseService("Coordenadas_xyz", conversion);
  
  ros::spin();
}

