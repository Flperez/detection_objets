#include "ros/ros.h"
#include "test/dat.h"
#include <cstdlib>
#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sys/stat.h>
#include <stdio.h> 
#include <iostream>
#include <string>

#include <sys/types.h>
#include <dirent.h>
#include "coordenadas/dat.h"
#define escalado 1

#define cx_d  254.878f
#define cy_d  205.395f
#define fx_d  365.456f
#define fy_d  365.456f


using namespace std;
using namespace cv;

Mat image_depth;


bool transformacion(coordenadas::dat::Request &req, coordenadas::dat::Response &res) 
{
	
	int u=req.uv[0];
	int v=req.uv[1];
	res.xyz.resize(3);
	

	printf("Ha llegado (%d,%d)\n",u,v);
	
	// 3D coordinates from point cloud using depth value.. in Kinect coordinate space
	res.xyz[2]= image_depth.at<ushort>(Point2d(u,v)) / 1000.0f;
	res.xyz[0]= (u - cx_d) * res.xyz[2]/ fx_d;
	res.xyz[1]= (v - cy_d) * res.xyz[2] / fy_d; 



	printf("x3D:%f y3D:%f z3D: %f \n",res.xyz[0],res.xyz[1],res.xyz[2]);
	
	
  
  return true;
}



class conversion
{
  ros::NodeHandle nh_,n;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  
  
public:
  conversion()
    : it_(nh_)
      
	 
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/kinect2/sd/image_depth", 1,
      &conversion::imageCb, this);
  }

	void imageCb(const sensor_msgs::ImageConstPtr& msg)
	{
    cv_bridge::CvImagePtr cv_ptr;
    cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::TYPE_16UC1);
    image_depth = cv_ptr->image;
	}

};


int main(int argc, char **argv) {
  ros::init(argc, argv, "Coordenadas_depth_image");
  ros::NodeHandle n;
ros::ServiceServer service = n.advertiseService("Coordenadas_xyz", transformacion);

  
  conversion  miConversion;
    ros::spin();

}







