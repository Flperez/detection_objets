#include "ros/ros.h"
#include "coordenadas/dat.h"
#include <cstdlib>

int main(int argc, char **argv) {
  ros::init(argc, argv, "envio_uv");

  ros::NodeHandle n;
  ros::ServiceClient client =   n.serviceClient<coordenadas::dat>("Coordenadas_xyz");
  coordenadas::dat srv;

  std::vector<double> x;
  

  x.push_back(256);
  x.push_back(212);


  srv.request.uv = x;

  if (client.call(srv)) 
	{

    for (int i = 0; i < 3; i++) 
	{
      printf("Sum: %f", (float)srv.response.xyz[i]);
    }
  } 
	else 
	{
    ROS_ERROR("Error en la llamada al servicio de Coordenadas_xyz");

	 }

    return 1;
}
