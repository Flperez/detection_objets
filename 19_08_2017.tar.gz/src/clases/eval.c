
/////////////////////////////////////////////////
///		EVAL			    /////
////////////////////////////////////////////////



#include "eval.h"


int eval::area_union(vector<int> detectado, vector<int> teorico)
{
/*
	x.at(0)->(min_x);
	x.at(1)->(max_x);		
	x.at(2)->(min_y);	
	x.at(3)->(max_y);
*/
	Mat img;
	int area_detectado = (detectado.at(1)-detectado.at(0))*(detectado.at(3)-detectado.at(2));
	int area_teorico = (teorico.at(1)-teorico.at(0))*(teorico.at(3)-teorico.at(2));
	int result = area_detectado+area_teorico-area_interseccion(detectado,teorico,img);
	
	return result;

}

int eval::area_interseccion(vector<int> detectado, vector<int> teorico,Mat &img)
{	
/*
	x.at(0)->(min_x);
	x.at(1)->(max_x);		
	x.at(2)->(min_y);	
	x.at(3)->(max_y);
*/
	Point pt1(0,0);
	Point pt2(0,0);
	
	
	//MIN_X
	if (detectado.at(0)>=teorico.at(0) && detectado.at(0)<=teorico.at(1))
	{
		pt1.x = detectado.at(0);
	}

	if (teorico.at(0)>detectado.at(0) && teorico.at(0)<detectado.at(1))
	{
		pt1.x = teorico.at(0);
	}
	
	//MIN_Y
	if (detectado.at(2)>=teorico.at(2) && detectado.at(2)<=teorico.at(3))
	{
		pt1.y = detectado.at(2);
	}

	if (teorico.at(2)>detectado.at(2) && teorico.at(2)<detectado.at(3))
	{
		pt1.y = teorico.at(2);
	}
	
	//MAX_X
	if (detectado.at(1)>=teorico.at(0) && detectado.at(1)<=teorico.at(1))
	{pt2.x = detectado.at(1);}
	if (teorico.at(1)>detectado.at(0) && teorico.at(1)<detectado.at(1))
	{pt2.x = teorico.at(1);}

	//MAX_Y
	if (detectado.at(3)>=teorico.at(2) && detectado.at(3)<=teorico.at(3))
	{pt2.y = detectado.at(3);}
	if (teorico.at(3)>detectado.at(2) && teorico.at(3)<detectado.at(3))
	{pt2.y = teorico.at(3);}

	//printf("Pt1(%d,%d)\tPt2(%d,%d)\n",pt1.x,pt1.y,pt2.x,pt2.y);

	int area = (pt2.x-pt1.x)*(pt2.y-pt1.y);
	if (!img.empty())
		rectangle(img,pt1,pt2,Scalar(255, 0, 0),2);
	
return area;

	
}

bool eval::solapamiento(int area_interseccion, int area_union,float umbral)
{
//cout<<"area union: "<<area_union<<endl;
//cout<<"area interseccion: "<<area_interseccion<<endl;

float criterio = (float)area_interseccion/(float)area_union;
//printf("Se encuentra superpuesto un %f %%\n",criterio*100);
if (criterio>umbral)
	return true;
else
	return false;

}


