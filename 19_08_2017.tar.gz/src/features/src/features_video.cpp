#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>


//CLASES UTILIZADAS
#include "../../clases/features.c"
#include "../../clases/accessFileString.c"
#include "../../clases/eval.c"
#include "../../clases/timer.c"

//PARA EL SERVICIO
#include "coordenadas/dat.h"



using namespace cv;
using namespace std;



/*Variables globales*/
//ejecutar 1 vez la entrada de argumentos
int flag=0;	

//para la introduccion de mas de una imagen para reconocer
char ** g_argv;
int numPhotos;

//para las funciones
features myfeatures;
accessFileString miAccess;

class ImageConverterFeature
{
  ros::NodeHandle nh_,n;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  ros::ServiceClient client;
  coordenadas::dat srv;
	

public:
	
	
  ImageConverterFeature()
    : it_(nh_)
      
	 
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/kinect2/hd/image_color", 1,&ImageConverterFeature::imageCbFeature, this);
   client =   n.serviceClient<coordenadas::dat>("Coordenadas_xyz");

    namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverterFeature()
  {
    destroyWindow(OPENCV_WINDOW);
  }

  void imageCbFeature(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
    
	Mat objectImg,sceneImg,originalObjectImg,sceneImgColor;	//imagenes del objeto y del esceneario	

	////////////////////////////////////////////////////////////////////////
	sceneImgColor = cv_ptr->image;
	
	//resize(sceneImgColor ,sceneImgColor , Size(512,424), 0, 0, CV_INTER_LINEAR); 


	sceneImg = sceneImgColor.clone();
	cvtColor(sceneImg, sceneImg, CV_BGR2GRAY); //convertimos a blanco y negro
	//para extraer la informacion del entorno y de las imagenes
	vector<KeyPoint> objectKeypoints;
	vector<KeyPoint> sceneKeypoints;
	Mat objectDescriptors;
	Mat sceneDescriptors;

	Timer tmr;
	
	
	for (int indice=0;indice<numPhotos;indice++)	//para pasar por todas las fotos
	{
	
		
		originalObjectImg = myfeatures.image_input(g_argv[indice+3],"features_video",0.25);
		objectImg = originalObjectImg.clone();
		cvtColor(objectImg, objectImg, CV_BGR2GRAY); //convertimos a blanco y negro
		////calculamos objectDescriptor y objectKeypoints
		string str1,str2;
		myfeatures.detect_extract_object(g_argv[1],g_argv[2],objectKeypoints,objectDescriptors,objectImg,str1,str2);
		
		int fin = 0;

		//BUSCAMOS REPETIDOS
		while(!fin)
		{	//Si encontramos uno eliminamos la zona-> cambio en la imagen del escenario
			//calculamos sceneDescriptor y sceneKeypoints
			//
			myfeatures.detect_extract_scene(g_argv[1],g_argv[2],sceneKeypoints,sceneDescriptors,sceneImg);
			
			



			/////////////////////////////////////////////////////////////////////////
			// NEAREST NEIGHBOR MATCHING USING FLANN LIBRARY (included in OpenCV)  //
			/////////////////////////////////////////////////////////////////////////
			Mat results;
			Mat dists;
			std::vector<std::vector<cv::DMatch> > matches;
	
			int k=2;

			if (objectDescriptors.type()==CV_8U)
			{
				
				
				
				//// Binary descriptors detected (from ORB, Brief, BRISK, FREAK)
				//printf("CV_8U\n");
				flann::Index flannIndex(sceneDescriptors, flann::LshIndexParams(12,20,2),cvflann::FLANN_DIST_HAMMING);
		
				flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
				

			}
			else
			{
				//asumimos que es CV_32F
				//Creamos Flann KDTree index
		
				
				//printf("CV_32F\n");
				flann::Index flannIndex(sceneDescriptors, flann::KDTreeIndexParams(),cvflann::FLANN_DIST_EUCLIDEAN);

				flannIndex.knnSearch(objectDescriptors,results,dists,k,flann::SearchParams());
				
			}
			//conversion a CV_32F si es necesario
			if (dists.type() == CV_32S)
			{
				//printf("CV_32S\n");
				Mat temp;
				dists.convertTo(temp,CV_32F);
				dists = temp;	
			}	
	
			////////////////////////////////////////
			//Procesamiento de el resultado del vecino mas cercano
			////////////////////////////////////////
			//Encontramos la correspondencia por NNDR (Nearest Neighbor Distance Ratio)
	
			float nndrRatio = 0.8;
			vector<Point2f> obj,scene;
			vector<int> indexes_1, indexes_2;
			vector<uchar> inlier_mask;

			
			for(unsigned int i=0; i<objectDescriptors.rows;i++)
			{	
				//printf("q=%d dist1=%f dist2=%f\n", i, dists.at<float>(i,0), dists.at<float>(i,1));
				if (results.at<int>(i,0)>=0 && results.at<int>(i,1)>=0 && dists.at<float>(i,0)<=nndrRatio * dists.at<float>(i,1))
				{
				obj.push_back(objectKeypoints.at(i).pt);
				indexes_1.push_back(i);
	

		
				scene.push_back(sceneKeypoints.at(results.at<int>(i,0)).pt);
				indexes_2.push_back(results.at<int>(i,0));

				}
		
			}	
			
	
		


			vector<KeyPoint> inliers1, inliers2;
			vector<DMatch> inlier_matches;
			string name = miAccess.readName(g_argv[indice+3]);
			
			int nbMatches = 8;
			if(obj.size() >= nbMatches)
			{

				Mat H = findHomography(obj,scene,RANSAC,1,inlier_mask);
				int inliers=0, outliers=0;
				for(unsigned int k=0; k<obj.size();++k)
					{
						if(inlier_mask.at(k))
						{
							inliers++;
						   
						}
						else
						{
							outliers++;
						}
					}
	
				//printf("inliers: %d\toutliers: %d\n",inliers,outliers);
				perspectiveTransform( obj, scene, H);	


				vector<Point2f> obj_corners(4);
				obj_corners[0] = Point(0,0); obj_corners[1] = Point( objectImg.cols, 0 );
				obj_corners[2] = Point( objectImg.cols, objectImg.rows ); 
				obj_corners[3] = Point( 0, objectImg.rows );
				vector<Point2f> scene_corners(4);

				perspectiveTransform( obj_corners, scene_corners, H);

			
		
			
		
	
				if(myfeatures.calcula_detectado(scene_corners)==true) //Detectado
				{	
					
					char str[50];sprintf(str,"%s detectado\n",name.c_str());ROS_INFO("%s",str);
					myfeatures.DrawBoundingBox(scene_corners,sceneImgColor,sceneImgColor,inliers,outliers,name);
					myfeatures.borrar_seccion(scene_corners,sceneImg);
					//Timer respuesta;
					srv.request.uv = myfeatures.centroUV(scene_corners, Point(1920,1080), Point(512,424));
					
					if(client.call(srv))
					{
					//double tr = respuesta.elapsed();
					//cout << "Duracion_resp: "<<tr <<endl;
					printf("(");
					for (int i = 0; i < 3; i++) 
					{
      				printf(" %f", (float)srv.response.xyz[i]);
    				}
					printf(")\n");
					}
											
					// Update GUI Window
    					imshow(OPENCV_WINDOW, sceneImgColor);	
								
					
				}
				else
				{
					fin = 1;	
					
				}
	
		
			}
			else
			{
				fin = 1;
				printf("No hay suficientes coincidencias (%d) para homografia\n", (int)obj.size());		
			}//homography		

		}//while(fin)--> Buscar repetidos
    }//for(numPhotos)
	double t = tmr.elapsed();
	//cout << "Nº imagenes: " << numPhotos<< "\tDuracion: "<<t << "s"<<std::endl;
	
	vector<double> tmedio;
	tmedio.push_back(t);double sumTotal=0;
	for (unsigned k = 0; k<tmedio.size();k++)
		{
			sumTotal = sumTotal+tmedio.at(k);
		}
	sumTotal=sumTotal/tmedio.size();
	cout<<"Tmedio: "<<sumTotal<<endl;	
	
	imshow(OPENCV_WINDOW, sceneImgColor);	
	//imshow("objeto",originalObjectImg);
	waitKey(1);

	

	
  }
};


	
int main(int argc, char** argv)
{
	//inicializacion
	ros::init(argc, argv, "features_video");
	
	
	//ejecutar la primera vez	
	if(!flag)
	{	
		if (argc<4 || atoi(argv[1])>8 || atoi(argv[2])>5)
			{myfeatures.showUsage("features_video");}
		g_argv = argv;
		numPhotos = argc-3;
		
		printf("Numero de fotos: %d.\n",numPhotos);
		//myfeatures.drawMultipleObject(numPhotos,argv);
		flag= 1;
	}
	
	//clase de ImageConverter
	ImageConverterFeature ic;

	ros::spin();	
	return 0;
}




