#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sys/stat.h>
#include <stdio.h> 
#include <iostream>
#include <string>

#include <sys/types.h>
#include <dirent.h>
#define escalado 1 


static const std::string OPENCV_WINDOW = "camara";
int numSnapshot = 0;
std::string snapshotFilename = "0";


std::string ruta = "/home/f/catkin_ws/Dataset/Toma_foto";


using namespace std;
using namespace cv;

	string rutaObject;
int getdir (string dir, vector<string> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir.c_str())) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {
        files.push_back(string(dirp->d_name));
    }
    closedir(dp);
    return 0;
}

class ImageConverterTomaFoto
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;

  

public:
  ImageConverterTomaFoto()
    : it_(nh_)
      
	 
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/kinect2/hd/image_color", 1,
      &ImageConverterTomaFoto::imageCbTF, this);
    

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverterTomaFoto()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }

  void imageCbTF(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {	
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {	
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
    
	
	char key = 0;

	Mat ResizeImage = cv_ptr->image;
	resize(ResizeImage , ResizeImage , Size(ResizeImage.cols*escalado,ResizeImage.rows*escalado), 0, 0, CV_INTER_LINEAR); 

	
	
	// Update GUI Window
	cv::imshow(OPENCV_WINDOW, ResizeImage);
	key = cv::waitKey(20);

	std::string ruta = rutaObject;
	
	if (key == 's')// &&  //si presionamos 's'
	{
		char str[20];
		sprintf(str,"%d",numSnapshot);
		std::string mistring(str);
		ruta.append("/"); ruta.append(mistring);ruta.append(".png");

		std::cout << "Has presionado la tecla 's'"	<< std::endl;
		cv::imwrite(ruta,cv_ptr->image);
		numSnapshot++;
	  	
		printf("El numero es: %d\n",numSnapshot);



	
 	}    

  
	
  }
};

int flag = 0;
int main(int argc, char** argv)
{

 ros::init(argc, argv, "toma_foto");
if(argc<2)
{
cout<<"\n\nUso:"<<endl<<"rosrun eval toma_foto nameObject"<<endl;exit(0);
}
if(!flag)
{
	rutaObject = string("/home/f/catkin_ws/Dataset/Toma_foto");
	string nameObject(argv[1]);
	flag = 1;


	vector<string> files = vector<string>();

	getdir(rutaObject,files);
	bool repetido = false;

	for (unsigned int i = 0;i < files.size();i++) 
	{
	    if( files[i] == nameObject)
		{repetido = true;
		}
	}
	rutaObject.append("/");rutaObject.append(nameObject);
	
	if (repetido == false)//no se ha creado previamente la carpeta
	{	
		cout<<"No se ha creado previamente la carpeta "<<nameObject<<endl;
		mkdir(rutaObject.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
		cout<<"Creada"<<endl;
		numSnapshot= 0;
	}
	
	else//se ha creado
	{	cout<<"Se ha creado previamente la carpeta "<<nameObject<<endl;


	

		vector<string> files = vector<string>();
		getdir(rutaObject,files);
		numSnapshot= (int)files.size()-2;



		cout<<"Numero de imagenes ya creadas: "<<numSnapshot<<endl;

			
		
	}


}


  ImageConverterTomaFoto icTF;
  ros::spin();
  return 0;
}

