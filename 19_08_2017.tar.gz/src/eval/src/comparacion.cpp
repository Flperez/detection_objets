#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <stdio.h>
#include <fstream>      // std::ifstream

#include "../../clases/features.c"
#include "../../clases/accessFileString.c"
#include "../../clases/eval.c"

#define inc_umbral 0.05
#define inicio_umbral 0.1
#define fin_umbral 1

using namespace std;
using namespace cv;

Mat img;
Point pt1,pt2;
accessFileString miaccess;
eval mieval;
features mifeatures;
const int tam = (fin_umbral-inicio_umbral)/inc_umbral;
float FPPI_array[tam];
float TE_array[tam];
float TD_array[tam];




int main(int argc, char** argv)
{
     if (argc < 3)
	{
	cout << "rosrun eval comparacion list_of_scene.txt list_of_gt.txt list_of_gd.txt"<< endl;
	return -1;	
	}
     
	
	int numPhotos =	miaccess.numPhotos(argv[1]);
	
	
	int numObjectGT = 0; 
	float TasaDeteccion,TasaError,FPPI;
	float umbral = 0.5;

	int RealesPositivos = 0;
	int FalsosPositivos = 0;	
	int k = 0;	
	for(umbral=inicio_umbral;umbral<=fin_umbral;umbral=umbral+inc_umbral)
	{
	for (int i=0;i<numPhotos;i++)
	{
		string rutaPhoto = miaccess.getRuta (argv[1], i);
		//cout << "Foto: "<<rutaPhoto<<endl;
		
		// Read image from file 
		img = imread(rutaPhoto,CV_LOAD_IMAGE_COLOR);

		 //if fail to read the image
		 if ( img.empty() ) 
		 { 
		      cout << "Error al cargar la imagen: " << rutaPhoto << endl;
		      return -1; 
		 }


		int numDeteccionTeorica = miaccess.numberofdeteccions(argv[2],rutaPhoto);
		int numDeteccionPractica = miaccess.numberofdeteccions(argv[3],rutaPhoto);
		
		numObjectGT = numObjectGT+numDeteccionTeorica;
		
		Point pt1D,pt2D;	//detectado
		Point pt1T,pt2T;	//teorico
		vector<Point2f> pdetectado(2),pteorico(2);

		string nameResultado = "/home/felipe/catkin_ws/src/Dataset/resultados_comparacion";
		string name_scene = miaccess.readName(rutaPhoto);
		nameResultado.append("/");
		nameResultado.append(name_scene);
		nameResultado.append(".png");
		

		for (int j=0;j<numDeteccionTeorica;j++)
		{				
			miaccess.extractDeteccions(argv[2],rutaPhoto,pt1T,pt2T,j);
			//printf("\tObjeto GT%d: x:[%d,%d] y:[%d,%d]\n",j,pt1.x,pt1.y,pt2,teorico.at(3));
			pdetectado[0]=pt1T;
			pdetectado[1]=pt2T;
				
			vector<int> teorico = mifeatures.limits(pdetectado);
			bool deteccion = false;
		
			rectangle(img,pt1T,pt2T,Scalar(0, 0, 255),3);
			
	
			//printf("\tObjeto GT%d: x:[%d,%d] y:[%d,%d]\n",j,teorico.at(0),teorico.at(1),teorico.at(2),teorico.at(3));
				
			
	
			for(int k=0;k<numDeteccionPractica;k++)
			{
				

				miaccess.extractDeteccions(argv[3],rutaPhoto,pt1D,pt2D,k);
				pteorico[0]=pt1D;
				pteorico[1]=pt2D;
				
				rectangle(img,pt1D,pt2D,Scalar(0, 255, 0),1);
				
				vector<int> detectado = mifeatures.limits(pteorico);


				int area_union = mieval.area_union(detectado,teorico);
				int area_interseccion = mieval.area_interseccion(detectado,teorico,img);
				//printf("\t\tObjeto VD%d: x:[%d,%d] y:[%d,%d],A_union:%d,A_intersec:%d\n",k,detectado.at(0),detectado.at(1),detectado.at(2),detectado.at(3),area_union,area_interseccion);

				if( mieval.solapamiento(area_interseccion,area_union,umbral)==true)
					{deteccion = true;break;}
				
			}
			
			if (deteccion == true)// se ha producido una deteccion
			{
				RealesPositivos++;		
			}
			
		

		}//for DeteccTeo
		
		if (numDeteccionPractica>numDeteccionTeorica)
			{
				FalsosPositivos = FalsosPositivos + (numDeteccionPractica-numDeteccionTeorica);			
			}
		imwrite(nameResultado,img);
	}//for imagenes

FPPI = FalsosPositivos/(float)numPhotos;
TasaDeteccion = RealesPositivos/(float)numObjectGT;
TasaError = 1 - TasaDeteccion;

cout<<"Umbral: "<<umbral<<endl;
cout <<"Numero de fotos: "<<numPhotos<<endl;
cout<<"Falsos Positivos: "<<FalsosPositivos<<endl;
cout<<"Reales Positivos: "<<RealesPositivos<<endl;
cout<<"Numero de objetos Ground Truth: "<<numObjectGT<<endl;

cout<<"FPPI: "<<FPPI<<endl;
cout<<"Tasa de Deteccion: "<<TasaDeteccion<<endl;
cout<<"Tasa error: "<<TasaError<<endl;
cout<<endl;

//guardamos en el historico
FPPI_array[k] = FPPI;
TE_array[k] = TasaError;
TD_array[k] = TasaDeteccion;
k++;

//reseteamos valores
FalsosPositivos = 0;
RealesPositivos = 0;
numObjectGT = 0;


}

for(int i=0;i<tam;i++)
	{umbral = (i*inc_umbral)+inicio_umbral;
	printf("umbral:%f FPPI:%f TE: %f\n",umbral,FPPI_array[i],TE_array[i]);
	}
return 0;

}


