#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <stdio.h>
#include <fstream>      // std::ifstream

#include "../../clases/features.c"
#include "../../clases/accessFileString.c"
#include "../../clases/eval.c"


using namespace std;
using namespace cv;

Mat img;
Point pt1,pt2;
bool LButton = false;
bool RButton = false;
accessFileString miaccess;
eval mieval;
features mifeatures;
int tickLeft = 0, tickRight = 0;
string mode= "0";


void CallBackFunc(int event, int x, int y, int flags, void* userdata)
{
     
	
     if  ( event == EVENT_LBUTTONDOWN )
     {
          cout << "Boton izquierdo presionado en (" << x << ", " << y << ")" << endl;
     	 // cout << "tickLeft: "<<tickLeft<<endl;
		if (tickLeft == 1)
		{
			pt2.x = x;
			pt2.y = y;
			mode = "rectangle";
			tickLeft = 0;
		} 
		else
		{
			pt1.x = x;
			pt1.y = y;
			tickLeft++;
		}
      
     }
     else if  ( event == EVENT_RBUTTONDOWN )
     {
          cout << "Boton derecho presionado en (" << x << ", " << y << ")" << endl;
		//cout << "tickRight"<<tickRight<<endl;
     	 if (tickRight == 1)
		{
			pt2.x = x;
			pt2.y = y;
			mode = "line";
			//tickRight = 0;
		} 
		else
		{
			pt1.x = x;
			pt1.y = y;
			tickRight++;
		}
      
	
     }
    
}

int main(int argc, char** argv)
{
     if (argc < 3)
	{
	cout << endl<<"USO:"<< endl<<endl;
	cout << "rosrun eval create_gt list_of_scene.txt list_of_gt.txt"<< endl;
	cout << "+ Modo rectangulo:"<< endl;
	cout << "  A traves del boton izquierdo seleccionas los dos vertices opuestos de la bounding box."<< endl;
	cout << "+ Modo linea:"<< endl;
	cout << "  A traves del boton derecho seleccionas las esquinas del objeto, generandose despues la bounding box."<< endl;
	cout << "\nPara pasar a la siguiente imagen pulsar 'n'.\n"<< endl;
	return -1;	
	}
     
	
	int numPhotos =	miaccess.numPhotos(argv[1]);
	cout << "Numero de fotos: "<<numPhotos<<" en el archivo: "<<argv[1]<<endl;
	
	for (int i=0;i<numPhotos;i++)
	{
		string rutaPhoto = miaccess.getRuta (argv[1], i);
		cout << "Foto: "<<rutaPhoto<<endl;
		
		// Read image from file 
		img = imread(rutaPhoto,CV_LOAD_IMAGE_COLOR);

		 //if fail to read the image
		 if ( img.empty() ) 
		 { 
		      cout << "Error al cargar la imagen: " << rutaPhoto << endl;
		      return -1; 
		 }


	

		 char key = '0';
		 //Create a window
		 namedWindow("My Window", 1);

		 //set the callback function for any mouse event
		 setMouseCallback("My Window", CallBackFunc, NULL);

		

		int contLine = 0;
		vector<Point2f> corners(4);
		 // Wait until user press some key
		
		if (miaccess.checkname(argv[2],rutaPhoto) == false)
		{cout<< "no se ha escrito "<<endl;
		ofstream file;
		file.open(argv[2],fstream::app);
		file << rutaPhoto<<"\n";
		file.close();
		}
		mode = "dibuja";
	
		while(key != 'n')
		{	
			if (mode == "dibuja")
				{	
					mode = "0";
					int num = miaccess.numberofdeteccions(argv[2], rutaPhoto);
					//cout << "Numero de detecciones pintadas previamente: "<<num<<endl;
					for (int i=0;i<num;i++)
					{
						miaccess.extractDeteccions(argv[2],rutaPhoto,pt1,pt2,i);

						rectangle(img,pt1,pt2,Scalar(0, 255, 0),2);
					}
					
				}
			if (mode == "rectangle")
				{
					mode = "0";
					//printf("pt1.x:%d pt1.y:%d pt2.x:%d pt2.y:%d\n",pt1.x,pt1.y,pt2.x,pt2.y);
					rectangle(img,pt1,pt2,Scalar(0, 255, 0),2);
					miaccess.writeinfile(argv[2],rutaPhoto,pt1,pt2);
				}
			if (mode == "line")
				{
					line(img, pt1 , pt2 , Scalar(0, 0, 255), 2 );
					pt1=pt2;
					mode = "0";
					corners[contLine] = pt2;										
					contLine++;

					if(contLine==4)
					{


						contLine = 0;tickRight=0;
						vector<int> mylimits = mifeatures.limits(corners);
						Point ptR1,ptR2;
						ptR1.x=mylimits.at(0);ptR1.y=mylimits.at(2);
						ptR2.x=mylimits.at(1);ptR2.y=mylimits.at(3);
						rectangle(img,ptR1,ptR2,Scalar(0, 255, 0),2);
						miaccess.writeinfile(argv[2],rutaPhoto,ptR1,ptR2);
						
					}
				}
			

			//show the image
			imshow("My Window", img);
			key=waitKey(1);
		}
}

	return 0;

}


