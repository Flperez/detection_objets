#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <stdio.h>
#include <fstream>      // std::ifstream

#include "../../clases/features.c"
#include "../../clases/accessFileString.c"
#include "../../clases/eval.c"


using namespace std;
using namespace cv;

Mat img;
Point pt1,pt2;
bool LButton = false;
bool RButton = false;
accessFileString miaccess;
eval mieval;
features mifeatures;
int tickLeft = 0, tickRight = 0;
string mode= "0";


void CallBackFunc(int event, int x, int y, int flags, void* userdata)
{
     
	
     if  ( event == EVENT_LBUTTONDOWN )
     {
          cout << "Boton izquierdo presionado en (" << x << ", " << y << ")" << endl;
     	 // cout << "tickLeft: "<<tickLeft<<endl;
		if (tickLeft == 1)
		{
			pt2.x = x;
			pt2.y = y;
			mode = "rectangle";
			tickLeft = 0;
		} 
		else
		{
			pt1.x = x;
			pt1.y = y;
			tickLeft++;
		}
      
     }
     else if  ( event == EVENT_RBUTTONDOWN )
     {
          cout << "Boton derecho presionado en (" << x << ", " << y << ")" << endl;
		//cout << "tickRight"<<tickRight<<endl;
     	 if (tickRight == 1)
		{
			pt2.x = x;
			pt2.y = y;
			mode = "line";
			//tickRight = 0;
		} 
		else
		{
			pt1.x = x;
			pt1.y = y;
			tickRight++;
		}
      
	
     }
    
}

int main(int argc, char** argv)
{
     if (argc < 2)
	{
	cout << endl<<"USO:"<< endl<<endl;
	cout << "rosrun eval recorte image.png"<< endl;
	cout << "+ Modo rectangulo:"<< endl;
	cout << "  A traves del boton izquierdo seleccionas los dos vertices opuestos de la bounding box."<< endl;
	cout << "+ Modo linea:"<< endl;
	cout << "  A traves del boton derecho seleccionas las esquinas del objeto, generandose despues la bounding box."<< endl;
	cout << "\nPara pasar a la siguiente imagen pulsar 'n'.\n"<< endl;
	return -1;	
	}
     
	
	
	

	
	
	// Read image from file 
	img = imread(argv[1],CV_LOAD_IMAGE_COLOR);

	 //if fail to read the image
	 if ( img.empty() ) 
	 { 
	      cout << "Error al cargar la imagen: " << argv[1] << endl;
	      return -1; 
	 }




	 char key = '0';
	 //Create a window
	 namedWindow("My Window", 1);

	 //set the callback function for any mouse event
	 setMouseCallback("My Window", CallBackFunc, NULL);

	

	int contLine = 0;
	vector<Point2f> corners(4);
	 // Wait until user press some key
	
	
	mode = "dibuja";
	
	Mat dst;
	double dstWidth = 0;
	double dstHeight=0;
	Mat imgOriginal = img.clone();
/*
	myvector.push_back(min_x);
	myvector.push_back(max_x);		
	myvector.push_back(min_y);	
	myvector.push_back(max_y)
*/
	
	while(key != 'q')
	{	
		
		if (mode == "rectangle")
			{
				
				corners[0]=pt1;
				corners[1]=pt2;
				corners[2]=Point(0,0);corners[3]=Point(0,0);
				mode = "recorta";
				
				//printf("pt1.x:%d pt1.y:%d pt2.x:%d pt2.y:%d\n",pt1.x,pt1.y,pt2.x,pt2.y);


				
			}
		if (mode == "line")
			{
				line(img, pt1 , pt2 , Scalar(0, 0, 255), 2 );
				pt1=pt2;
				mode = "0";
				corners[contLine] = pt2;										
				contLine++;

				if(contLine==4)
				{


					contLine = 0;tickRight=0; mode = "recorta";
				


					
				}
			}
		if (mode == "recorta")
			{
			vector<int> mylimits = mifeatures.limits(corners);
				Point ptR1,ptR2;
				ptR1.x=mylimits.at(0);ptR1.y=mylimits.at(2);
				ptR2.x=mylimits.at(1);ptR2.y=mylimits.at(3);
				rectangle(img,ptR1,ptR2,Scalar(0, 255, 0),2);
				dstWidth = ptR2.x-ptR1.x;
				dstHeight = ptR2.y-ptR1.y;

				
				Rect cut(ptR1.x,ptR1.y,dstWidth,dstHeight);
				dst = Mat(dstHeight, dstWidth, CV_8UC3, cv::Scalar(0,0,0));

				

				 dst = imgOriginal(cut);
				mode ="espera";
				cout<<"Si desea recortar el area seleccionada pulse 's'"<<endl;
				cout<<"Si no desea recortar el area seleccionada pulse 'n'"<<endl;

			}
		
		if (mode == "espera")
		{
			if (key == 's')
			{	string recorteRuta(argv[1]);
				recorteRuta.erase(recorteRuta.length()-4,4);
				recorteRuta.append("_recortado.png");
				imshow("Recorte", dst);	
		         	imwrite(recorteRuta,dst);
				key = 'q';
			}
			if (key == 'n')
			{
				mode = "0";
				img = imgOriginal;				
			}		
		}
		//show the image
		imshow("My Window", img);
		key=waitKey(1);
	}


	return 0;

}


