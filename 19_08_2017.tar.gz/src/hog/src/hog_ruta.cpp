#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sys/stat.h>
#include <stdio.h> 
#include <ios>
#include <fstream>
#include <stdexcept>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>

#define SVMLIGHT 1
#define LIBSVM 2

//#define TRAINHOG_USEDSVM SVMLIGHT
#define TRAINHOG_USEDSVM SVMLIGHT

#if TRAINHOG_USEDSVM == SVMLIGHT
    #include "svmlight/svmlight.h"
    #define TRAINHOG_SVM_TO_TRAIN SVMlight
#elif TRAINHOG_USEDSVM == LIBSVM
    #include "libsvm/libsvm.h"
    #define TRAINHOG_SVM_TO_TRAIN libSVM
#endif

#include "../../clases/features.c"
#include "../../clases/accessFileString.c"
#include "../../clases/eval.c"
#include "../../clases/timer.c"


using namespace std;
using namespace cv;


// Set the file to write the SVM model to
static string svmModelFile = "/home/felipe/catkin_ws/src/Dataset/genfiles/svmlightmodel.dat";

// Set the file to write the resulting opencv hog classifier as YAML file
static string cvHOGFile = "/home/felipe/catkin_ws/src/Dataset/genfiles/cvHOGClassifier.yaml";

// HOG parameters for training that for some reason are not included in the HOG class

static const Size winStride = Size(8, 8);


HOGDescriptor hog; // Use standard parameters here

 double hitThreshold;
 int flag=0;

static void showDetections(const vector<Rect>& found, Mat& imageData,  vector<Rect> &found_filtered);
static void detectTest(const HOGDescriptor& hog, const double hitThreshold, Mat imageData, vector<Rect> &found_filtered);





int main(int argc, char** argv)
{
	features myfeatures;
	if(argc<3)
	{
		myfeatures.showUsage("hog_ruta");		
	}
	
	accessFileString miAccess;

	
	hog.winSize = Size(64, 128); // Default training images size as used in paper;
	setlocale(LC_NUMERIC,"C");
    setlocale(LC_ALL, "POSIX");
    TRAINHOG_SVM_TO_TRAIN::getInstance()->loadModelFromFile(svmModelFile);
    // Detector detection tolerance threshold
    hitThreshold = TRAINHOG_SVM_TO_TRAIN::getInstance()->getThreshold();
	hog.load(cvHOGFile);	
	
 
	int numPhotosScene = miAccess.numPhotos(argv[1]);
	printf("Numero de fotos de escenarios:%d\n",numPhotosScene);

	for(int i=0;i<numPhotosScene;i++)
	{
		string rutaScene =  miAccess.getRuta (argv[1],i);
		string name_scene = miAccess.readName(rutaScene);
		printf("Imagen: %s\n",rutaScene.c_str());
		string rutaFile(argv[2]);	
	

		vector<Rect> found;
		Mat testImageColor = myfeatures.image_input(rutaScene,"hog_ruta",1);
		Mat testImage = testImageColor.clone();
		cvtColor(testImage, testImage, CV_BGR2GRAY); // Work on grayscale images as trained
		detectTest(hog, hitThreshold, testImage,found);

	
		ofstream file;file.open(rutaFile.c_str(),fstream::app);
		file << rutaScene<<"\n";//primero escribimos el nombre de la imagen en el fichero
		file.close();
	
		if (found.size() != 0)	//se ha detectado algo
		{
			for (i = 0; i < found.size(); i++) 
			{
		    Rect r = found[i];
			miAccess.writeinfile(rutaFile,rutaScene, r.tl(), r.br());
			}
		}


   
 	}

  return 0;
}

static void showDetections(const vector<Rect>& found, Mat& imageData, vector<Rect> &found_filtered) {
    
    size_t i, j;
    for (i = 0; i < found.size(); ++i) {
        Rect r = found[i];
        for (j = 0; j < found.size(); ++j)
            if (j != i && (r & found[j]) == r)
                break;
        if (j == found.size())
            found_filtered.push_back(r);
    }
    for (i = 0; i < found_filtered.size(); i++) {
        Rect r = found_filtered[i];
        rectangle(imageData, r.tl(), r.br(), Scalar(0, 255, 0), 3);
		ROS_INFO("detectado");
		
    }
}


/**
 * Test detection with custom HOG description vector
 * @param hog
 * @param hitThreshold threshold value for detection
 * @param imageData
*/
static void detectTest(const HOGDescriptor& hog, const double hitThreshold, Mat imageData, vector<Rect> &found_filtered) {
    vector<Rect> found;
	
    Size padding(Size(8, 8));
    Size winStride(Size(8, 8));
    hog.detectMultiScale(imageData, found, hitThreshold, winStride, padding);
    showDetections(found, imageData,found_filtered);
}


