#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sys/stat.h>
#include <stdio.h> 
#include <ios>
#include <fstream>
#include <stdexcept>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>

#define SVMLIGHT 1
#define LIBSVM 2

//#define TRAINHOG_USEDSVM SVMLIGHT
#define TRAINHOG_USEDSVM SVMLIGHT

#if TRAINHOG_USEDSVM == SVMLIGHT
    #include "svmlight/svmlight.h"
    #define TRAINHOG_SVM_TO_TRAIN SVMlight
#elif TRAINHOG_USEDSVM == LIBSVM
    #include "libsvm/libsvm.h"
    #define TRAINHOG_SVM_TO_TRAIN libSVM
#endif

using namespace std;
using namespace cv;


// Set the file to write the SVM model to
static string svmModelFile = "/home/felipe/catkin_ws/src/Dataset/genfiles/svmlightmodel.dat";
// Set the file to write the resulting detecting descriptor vector to
static string descriptorVectorFile = "/home/felipe/catkin_ws/src/Dataset/genfiles/descriptorvector.dat";
// Set the file to write the resulting opencv hog classifier as YAML file
static string cvHOGFile = "/home/felipe/catkin_ws/src/Dataset/genfiles/cvHOGClassifier.yaml";

// HOG parameters for training that for some reason are not included in the HOG class

static const Size winStride = Size(8, 8);

static const std::string OPENCV_WINDOW = "camara";
    HOGDescriptor hog; // Use standard parameters here

 double hitThreshold;
 int flag=0;

static void showDetections(const vector<Rect>& found, Mat& imageData);
static void detectTest(const HOGDescriptor& hog, const double hitThreshold, Mat& imageData);

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  int numSnapshot;

public:
  ImageConverter()
    : it_(nh_)
      
	 
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/usb_cam/image_raw", 1,
      &ImageConverter::imageCb, this);
    image_pub_ = it_.advertise("/image_converter/output_video", 1);

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
    
	
	char key = 0;

	Mat testImage = cv_ptr->image;
	cvtColor(testImage, testImage, CV_BGR2GRAY); // Work on grayscale images as trained
    detectTest(hog, hitThreshold, testImage);
    
    	
	// Update GUI Window
	cv::imshow(OPENCV_WINDOW, testImage);
	cv::waitKey(1);

    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
	
  }
};

int main(int argc, char** argv)
{

  ros::init(argc, argv, "toma_foto");

	if(!flag)
	{flag= 1;
	hog.winSize = Size(64, 128); // Default training images size as used in paper;
	setlocale(LC_NUMERIC,"C");
    setlocale(LC_ALL, "POSIX");
    TRAINHOG_SVM_TO_TRAIN::getInstance()->loadModelFromFile(svmModelFile);
    // Detector detection tolerance threshold
     hitThreshold = TRAINHOG_SVM_TO_TRAIN::getInstance()->getThreshold();
	  hog.load(cvHOGFile);	
	ROS_INFO("cargado el hog");
	}
 
   
  ImageConverter ic;
  ros::spin();
  return 0;
}

static void showDetections(const vector<Rect>& found, Mat& imageData) {
    vector<Rect> found_filtered;
    size_t i, j;
    for (i = 0; i < found.size(); ++i) {
        Rect r = found[i];
        for (j = 0; j < found.size(); ++j)
            if (j != i && (r & found[j]) == r)
                break;
        if (j == found.size())
            found_filtered.push_back(r);
    }
    for (i = 0; i < found_filtered.size(); i++) {
        Rect r = found_filtered[i];
        rectangle(imageData, r.tl(), r.br(), Scalar(64, 255, 64), 3);
    }
}


/**
 * Test detection with custom HOG description vector
 * @param hog
 * @param hitThreshold threshold value for detection
 * @param imageData
 */
static void detectTest(const HOGDescriptor& hog, const double hitThreshold, Mat& imageData) {
    vector<Rect> found;
    Size padding(Size(8, 8));
    Size winStride(Size(8, 8));
    hog.detectMultiScale(imageData, found, hitThreshold, winStride, padding);
    showDetections(found, imageData);
}


