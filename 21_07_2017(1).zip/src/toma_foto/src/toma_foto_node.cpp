#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sys/stat.h>
#include <stdio.h> 
/*
1º Falta que cree una carpeta con un nombre y que guarde las fotos ahi,
2º cree un fichero .txt con la lista de archivos:
	/home/felipe/catkin_ws/src/toma_foto/fotos/boligrafo/1.png
	/home/felipe/catkin_ws/src/toma_foto/fotos/boligrafo/2.png
	....
3º a la hora de echar fotos compruebe cual fue la ultima en la carpeta 

*/

static const std::string OPENCV_WINDOW = "camara";
int numSnapshot = 0;
std::string snapshotFilename = "0";


std::string ruta = "/home/felipe/catkin_ws/src/toma_foto/fotos";
char ruta_modelo[100] = "/home/felipe/catkin_ws/src/toma_foto/modelos";
char ruta_fichero[100] = "/home/felipe/catkin_ws/src/toma_foto/modelos/milista.txt";
char nombre_modelo[100]="faber_castell";



class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  int numSnapshot;

public:
  ImageConverter()
    : it_(nh_)
      
	 
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/usb_cam/image_raw", 1,
      &ImageConverter::imageCb, this);
    image_pub_ = it_.advertise("/image_converter/output_video", 1);

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
    
	
	char key = 0;



    
	//std::cout << "Press 's' to take snapshots" << std::endl;
	
	
	// Update GUI Window
    cv::imshow(OPENCV_WINDOW, cv_ptr->image);
	key = cv::waitKey(20);

	
	if (key == 115)// && girado = 1) //si presionamos 's'
	{
	  std::cout << "Has presionado la tecla 's'"	<< std::endl;
      cv::imwrite(ruta + "/" + snapshotFilename + ".png", cv_ptr->image);
      numSnapshot++;
	  
      snapshotFilename = static_cast<std::ostringstream*>(&(std::ostringstream() << numSnapshot))->str();
	  printf("El numero es: %d\n",numSnapshot);



	
 	}    

    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
	
  }
};

int main(int argc, char** argv)
{
  FILE *fichero;
  ros::init(argc, argv, "toma_foto");
	/*  
	printf("%s",ruta_fichero);
  fichero = fopen( ruta_fichero, "rw" );
  fprintf(fichero, "%s\n", nombre_modelo);
  fclose(fichero);
  
   strcat(ruta_modelo,"/"); strcat(ruta_modelo,nombre_modelo);
  mkdir(ruta_modelo,0777);
		

  */

  ImageConverter ic;
  ros::spin();
  return 0;
}
